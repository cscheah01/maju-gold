<?php

namespace App\Services\User;

use Exception;
use App\Services\Service;
use App\Repositories\UserPackageTradingRecordRepository;

class UserPackageTradingRecordUserService extends Service
{
    protected $_userPackageTradingRecordRepository;

    public function __construct(
        UserPackageTradingRecordRepository $userPackageTradingRecordRepository
    ) {
        $this->_userPackageTradingRecordRepository = $userPackageTradingRecordRepository;
    }

    public function getPackageTradingRecordByUserPackageId($userPackageId)
    {
        try {
            $packageTradingRecords = $this->_userPackageTradingRecordRepository->getByUserPackageId($userPackageId);

            return $packageTradingRecords;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/package.Fail_To_Get_Package_Trading_Record'));

            return null;
        }
    }
}

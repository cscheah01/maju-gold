<?php

namespace App\Repositories;


class Repository
{
    public function getAll()
    {
        $data = $this->_db->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getById($id)
    {
        $data = $this->_db->find($id);

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function deleteById($id)
    {
        $data = $this->getById($id);

        if (empty($data)) {
            return null;
        }

        $data->delete();
        return $data;
    }
}

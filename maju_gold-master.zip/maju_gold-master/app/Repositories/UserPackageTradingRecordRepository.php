<?php

namespace App\Repositories;

use Carbon\Carbon;
use App\Models\UserPackageTradingRecord;

class UserPackageTradingRecordRepository extends Repository
{
    protected $_db;

    public function __construct(UserPackageTradingRecord $userPackageTradingRecord)
    {
        $this->_db = $userPackageTradingRecord;
    }

    public function bulkSave($data, $userPackageId)
    {
        $userPackageTradingStatistic = [];
        foreach ($data as $statistic) {
            $userPackageTradingStatistic[] = [
                "user_package_id" => $userPackageId,
                "date" =>  $statistic['date'],
                "percent" =>  $statistic['percent'],
                "current_value" =>  $statistic['current_value'],
                'created_at' => Carbon::now()->toDateTimeString(),
                'updated_at' => Carbon::now()->toDateTimeString()
            ];
        }

        $this->_db->insert($userPackageTradingStatistic);
        return $data;
    }

    public function deleteByDateAndUserPackageId($date, $userPackageId)
    {
        $this->_db->where('user_package_id', '=', $userPackageId)->whereDate('date', '>', $date)->delete();

        return true;
    }

    public function getByUserPackageIdAndDate($userPackageId, $date)
    {
        $data = $this->_db
            ->where('user_package_id', '=', $userPackageId)
            ->whereDate('date', '=', $date)
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getIncommingRecordByUserPackageIdAndDate($userPackageId, $date)
    {
        $data = $this->_db
            ->where('user_package_id', '=', $userPackageId)
            ->whereDate('date', '>', $date)
            ->get();

        if ($data->isEmpty()) {
            return null;
        }

        return $data;
    }

    public function getByUserPackageId($userPackageId)
    {
        $data = $this->_db
            ->where('user_package_id', '=', $userPackageId)
            ->whereDate('date', '<=', Carbon::today())
            ->orderBy('date', 'asc')
            ->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getAllByUserPackageId($userPackageId)
    {
        $data = $this->_db
            ->where('user_package_id', '=', $userPackageId)
            ->orderBy('date', 'asc')
            ->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}

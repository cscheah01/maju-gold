<?php

namespace App\Services\Admin;

use Exception;
use Carbon\Carbon;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Validator;
use App\Exports\UserCommissionReportExport;
use App\Repositories\UserCommissionRepository;

class UserCommissionAdminService extends Service
{
    protected $_userCommissionRepository;

    public function __construct(
        UserCommissionRepository $userCommissionRepository
    ) {
        $this->_userCommissionRepository = $userCommissionRepository;
    }

    public function getDataTable($filterData)
    {
        $data = DB::table('user_commissions')
            ->leftjoin('users', 'user_commissions.user_id', '=', 'users.id')
            ->select([
                'user_commissions.user_id',
                'users.name as user_name',
                'users.phone_number as user_phone_number',
                DB::raw("(DATE_FORMAT(user_commissions.created_at, '%m-%Y')) as month_year"),
                DB::raw("SUM(amount) as amount")
            ])->groupBy('users.name', 'users.phone_number', 'user_commissions.user_id', DB::raw("DATE_FORMAT(user_commissions.created_at, '%m-%Y')"));


        if (isset($filterData['month'])) {
            $data->whereMonth('user_commissions.created_at', '=', $filterData['month']);
        }

        if (isset($filterData['year'])) {
            $data->whereYear('user_commissions.created_at', '=', $filterData['year']);
        }


        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function exportUserCommissionReportExcel($data)
    {
        try {
            $validator = Validator::make($data, [
                'user_id' => 'nullable',
                'month_year' => 'nullable',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            if (isset($data['month_year'])) {
                $date = Carbon::createFromFormat('Y-m', $data['month_year']);
                $data['year'] = $date->format('Y');
                $data['month'] = $date->format('m');
            }

            return Excel::download(new UserCommissionReportExport($data), 'user-commission-report.csv');
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to export user commission report.");

            return null;
        }
    }
}

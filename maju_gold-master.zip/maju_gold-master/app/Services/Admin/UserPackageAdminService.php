<?php

namespace App\Services\Admin;

use Exception;
use Carbon\Carbon;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Enums\UserInvestmentStatus;
use App\Repositories\UserPackageRepository;

class UserPackageAdminService extends Service
{
    protected $_userPackageRepository;

    public function __construct(
        UserPackageRepository $userPackageRepository
    ) {
        $this->_userPackageRepository = $userPackageRepository;
    }

    public function getDataTable($filterData)
    {

        $data = DB::table('user_packages')
            ->leftJoin('users', 'user_packages.user_id', 'users.id')
            ->select([
                'user_packages.id',
                'user_packages.name',
                'user_packages.return_profit_percent',
                'user_packages.return_profit_days',
                'user_packages.return_profit_date',
                'user_packages.is_withdrawn',
                'user_packages.created_at',
                'users.id as user_id',
                'users.name as user_name',
                'users.phone_number as phone_number',
            ]);

        if (!empty($filterData['created_at_from'])) {
            $data->whereDate('user_packages.created_at', '>=', $filterData['created_at_from']);
        }

        if (!empty($filterData['created_at_to'])) {
            $data->whereDate('user_packages.created_at', '<=', $filterData['created_at_to']);
        }

        if (!empty($filterData['return_profit_date_from'])) {
            $data->whereDate('user_packages.return_profit_date', '>=', $filterData['return_profit_date_from']);
        }

        if (!empty($filterData['return_profit_date_to'])) {
            $data->whereDate('user_packages.return_profit_date', '<=', $filterData['return_profit_date_to']);
        }


        if (isset($filterData['status'])) {
            if ($filterData['status'] == UserInvestmentStatus::PendingWithdrawn()->key) {
                $data->where('user_packages.return_profit_date', '<=', Carbon::today());
            } else if ($filterData['status'] == UserInvestmentStatus::Investing()->key) {
                $data->where('user_packages.is_withdrawn', '=', false);
                $data->where('user_packages.return_profit_date', '>', Carbon::today());
            } else if ($filterData['status'] == UserInvestmentStatus::Withdrawn()->key) {
                $data->where('user_packages.is_withdrawn', '=', true);
            }
        }

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $userPackage = $this->_userPackageRepository->getById($id);

            if ($userPackage == null) {
                return false;
            }
            if ($userPackage->is_withdrawn) {
                $userPackage->withdraw_price = number_format($userPackage->price * (1 + ($userPackage->return_profit_percent / 100)), 2, '.', '');
            }

            return $userPackage;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get user package details.");

            return null;
        }
    }

    public function downloadCertificate($id)
    {
        try {
            $userPackage = $this->_userPackageRepository->getById($id);

            if ($userPackage == null) {
                throw new Exception();
            }

            $certificateName = $userPackage->certificate;

            $filePath = public_path('storage/user_package_certificate/' . $certificateName);

            $fileName = "investment_certificate.jpg";

            return response()->download($filePath, $fileName);
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to download certificate.");

            return null;
        }
    }
}

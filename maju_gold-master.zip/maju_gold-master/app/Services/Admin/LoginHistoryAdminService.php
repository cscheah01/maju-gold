<?php

namespace App\Services\Admin;

use App\Services\Service;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;

class LoginHistoryAdminService extends Service
{

    public function getDataTable($filterData)
    {
        $data = DB::table('login_histories')
            ->leftJoin('users', 'login_histories.user_id', 'users.id')
            ->select([
                'login_histories.user_id',
                'login_histories.ip_address',
                'login_histories.country',
                'login_histories.created_at',
                'users.email',
            ]);

        if (!empty($filterData['date_from'])) {
            $data->where('login_histories.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('login_histories.created_at', '<=', $filterData['date_to']);
        }

        if (!empty($filterData['user_id'])) {
            $data->where('login_histories.user_id', '=', $filterData['user_id']);
        }

        $result = DataTables::of($data)
            ->make();

        return $result;
    }
}

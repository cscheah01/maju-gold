<?php

namespace App\Repositories;

use App\Models\UserCommission;

class UserCommissionRepository extends Repository
{
    protected $_db;

    public function __construct(UserCommission $userCommission)
    {
        $this->_db = $userCommission;
    }

    public function save($data)
    {
        $model = new UserCommission;
        $model->user_id = $data['user_id'];
        $model->downline_user_id = $data['downline_user_id'];
        $model->user_package_id = $data['user_package_id'];
        $model->percent = $data['percent'];
        $model->amount = $data['amount'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->user_id = $data['user_id'] ?? $model->user_id;
        $model->downline_user_id = $data['downline_user_id'] ?? $model->downline_user_id;
        $model->user_package_id = $data['user_package_id'] ?? $model->user_package_id;
        $model->percent = $data['percent'] ?? $model->percent;
        $model->amount = $data['amount'] ?? $model->amount;

        $model->update();
        return $model;
    }
}

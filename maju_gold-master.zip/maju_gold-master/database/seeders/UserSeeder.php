<?php

namespace Database\Seeders;

use App\Models\User;
use App\Enums\LanguageType;
use App\Enums\UserType;
use Illuminate\Support\Str;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'user',
            'email' => 'user@user.com',
            'ic_passport' => '123456789123',
            'phone_number' => '0123456789',
            'birthday' => '2022-1-1',
            'password' => bcrypt('12345678'),
            'language' => LanguageType::En()->key,
            'code' => Str::random(10)
        ]);

        $user->assignRole('user');
        $user->assignRole(UserType::Partner()->key);

        $user->partner_user_id = $user->id;
        $user->update();

        $user = User::create([
            'name' => 'admin',
            'email' => 'admin@admin.com',
            'password' => bcrypt('12345678'),
            'language' => LanguageType::En()->key
        ]);

        $user->assignRole('admin');
    }
}

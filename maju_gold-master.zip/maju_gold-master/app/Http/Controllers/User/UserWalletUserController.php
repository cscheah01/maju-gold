<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Services\User\UserWalletUserService;

class UserWalletUserController extends Controller
{
    private $_userWalletUserService;

    public function __construct(
        UserWalletUserService $userWalletUserService,
    ) {
        $this->_userWalletUserService = $userWalletUserService;
    }

    public function index()
    {
        $userId = Auth::id();
        $wallet = $this->_userWalletUserService->getWalletByUserId($userId);

        return view('user/wallet/index', compact('wallet'));
    }

    public function dataTable()
    {
        $data = $this->_userWalletUserService->getDataTable();

        return $data;
    }

    public function withdraw(Request $request)
    {
        $data = $request->only([
            'amount',
        ]);

        $result = $this->_userWalletUserService->walletWithdrawRequest($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userWalletUserService->_errorMessage);

            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success',  __('user/wallet.Wallet_withdrawal_request_successfully_sent'));
    }
}

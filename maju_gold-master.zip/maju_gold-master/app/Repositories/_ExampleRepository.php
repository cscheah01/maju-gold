<?php

namespace App\Repositories;


class ExampleRepository extends Repository
{
    // protected $_db;

    // public function __construct(User $user)
    // {
    //     $this->_db = $user;
    // }
}

<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\Admin\UserCommissionAdminService;

class UserCommissionAdminController extends Controller
{
    private $_userCommissionAdminService;

    public function __construct(
        UserCommissionAdminService $userCommissionAdminService,
    ) {
        $this->_userCommissionAdminService = $userCommissionAdminService;
    }

    public function index()
    {
        return view('admin/user_commission/index');
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'month',
            'year',
        ]);

        $data = $this->_userCommissionAdminService->getDataTable($filterData);

        return $data;
    }

    public function export(Request $request)
    {
        $data = $request->only([
            'user_id',
            'month_year',
        ]);

        $result = $this->_userCommissionAdminService->exportUserCommissionReportExcel($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userCommissionAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return $result;
    }
}

<?php

namespace App\Services\User;

use Image;
use Exception;
use Carbon\Carbon;
use App\Enums\UserType;
use App\Services\Service;
use Illuminate\Support\Str;
use App\Enums\ReferralLevel;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use App\Repositories\PackageRepository;
use Illuminate\Support\Facades\Validator;
use App\Repositories\UserWalletRepository;
use App\Repositories\UserPackageRepository;
use App\Repositories\UserCommissionRepository;
use App\Repositories\UserWalletTransactionRepository;
use App\Repositories\PackageWithdrawalRequestRepository;
use App\Repositories\UserPackageTradingRecordRepository;
use App\Repositories\UserRepository;

class UserPackageUserService extends Service
{
    protected $_userPackageRepository;
    protected $_userPackageTradingRecordRepository;
    protected $_packageRepository;
    protected $_packageWithdrawalRequestRepository;
    protected $_userWalletUserService;
    protected $_userWalletRepository;
    protected $_userWalletTransactionRepository;
    protected $_userCommissionRepository;
    protected $_partnerGroupCommissionLevelUserService;
    protected $_userRepository;

    public function __construct(
        UserPackageRepository $userPackageRepository,
        UserPackageTradingRecordRepository $userPackageTradingRecordRepository,
        PackageRepository $packageRepository,
        PackageWithdrawalRequestRepository $packageWithdrawalRequestRepository,
        UserWalletUserService $userWalletUserService,
        UserWalletRepository $userWalletRepository,
        UserWalletTransactionRepository $userWalletTransactionRepository,
        UserCommissionRepository $userCommissionRepository,
        PartnerGroupCommissionLevelUserService $partnerGroupCommissionLevelUserService,
        UserRepository $userRepository
    ) {
        $this->_userPackageRepository = $userPackageRepository;
        $this->_userPackageTradingRecordRepository = $userPackageTradingRecordRepository;
        $this->_packageRepository = $packageRepository;
        $this->_packageWithdrawalRequestRepository = $packageWithdrawalRequestRepository;
        $this->_userWalletUserService = $userWalletUserService;
        $this->_userWalletRepository = $userWalletRepository;
        $this->_userWalletTransactionRepository = $userWalletTransactionRepository;
        $this->_userCommissionRepository = $userCommissionRepository;
        $this->_partnerGroupCommissionLevelUserService = $partnerGroupCommissionLevelUserService;
        $this->_userRepository = $userRepository;
    }

    public function getCurrentPackage($userId)
    {
        try {
            $userPackage = $this->_userPackageRepository->getFirstByUserIdAndIsWithdrawn($userId, false);

            if ($userPackage != null) {
                $today = Carbon::now()->format('Y-m-d');

                $userPackage->return_profit_date = date('Y-m-d', strtotime($userPackage->return_profit_date));


                //calculation for remaining day
                $userPackage->remaining_days = ($userPackage->return_profit_date > $today) ? (now()->diffInDays($userPackage->return_profit_date)) + 1 : 0;


                //get today package value
                $userPackage->total_earnings = $userPackage->price;

                if (date('Y-m-d', strtotime($userPackage->created_at)) != $today) {
                    $viewableLastDate = ($userPackage->return_profit_date > $today) ? $today : $userPackage->return_profit_date;
                    $viewableLastUserPackageTradingRecord = $this->_userPackageTradingRecordRepository->getByUserPackageIdAndDate($userPackage->id, $viewableLastDate);

                    $userPackage->total_earnings = $viewableLastUserPackageTradingRecord->current_value;
                }
            }

            return $userPackage ? $userPackage->toArray() : null;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/package.Fail_to_get_package_details'));

            return null;
        }
    }

    //pending_review
    public function getAllPackage()
    {
        try {
            $data = $this->_packageRepository->getAll();

            $package = $data->toArray();

            return $package;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/package.Fail_to_get_all_package'));

            return null;
        }
    }

    public function getDataTable()
    {
        $userId = Auth::id();

        $data = DB::table('user_packages')
            ->select([
                'user_packages.id',
                'user_packages.name',
                'user_packages.price',
                'user_packages.is_withdrawn',
                'user_packages.certificate',
                'user_packages.created_at',
                DB::raw('(user_packages.price *(1+(user_packages.return_profit_percent/100))) as withdraw_price')
            ])
            ->where('user_packages.user_id', '=', $userId);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getWithdrawnPackage($userId)
    {
        try {
            $withdrawnPackage = $this->_userPackageRepository->getFirstByUserIdAndIsWithdrawn($userId, true);

            if ($withdrawnPackage != null) {
                return true;
            }

            return $withdrawnPackage;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/package.Fail_to_get_user_withdrawn_package'));

            return null;
        }
    }

    //pending_review
    public function getAllPackageExcludeNewUserPackage()
    {
        try {
            $data = $this->_packageRepository->getAllPackageExcludeNewUserPackage();

            $package = $data->toArray();

            return $package;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/package.Fail_to_get_all_package_excluded_new_user_package'));

            return null;
        }
    }

    public function createUserPackage($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'package_id' => 'required',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $user = Auth::user();
            $data['user_id'] = $user->id;
            $package = $this->_packageRepository->getById($data['package_id']);
            $userPackage = $this->_userPackageRepository->getFirstByUserIdAndIsWithdrawn($data['user_id'], false);

            if ($package == null || $userPackage != null) {
                throw new Exception();
            }


            //check user able to buy new user package
            if ($package->is_for_new_user) {
                $userWithdrawnPackage = $this->getWithdrawnPackage($data['user_id']);

                if ($userWithdrawnPackage == true) {
                    throw new Exception();
                }
            }

            $data['name'] = $package->name;
            $data['price'] = $package->price;
            $data['gram'] = $package->gram;
            $data['return_profit_percent'] = $package->return_profit_percent;
            $data['return_profit_days'] = $package->return_profit_days;
            $data['return_profit_date'] = Carbon::now()->addDay($package->return_profit_days);
            $data['is_withdrawn'] = false;

            $userPackage = $this->_userPackageRepository->save($data);


            //generate certificate
            $emptyCertificate = Image::make(public_path('img/maju-gold-certificate-blank.jpg'));
            $certificateFileName = $this->generateFileName();
            $certificateFileName = $certificateFileName . '.jpg';

            $certificateStoragePath = public_path('storage/user_package_certificate');
            File::ensureDirectoryExists($certificateStoragePath);

            $emptyCertificate->text('ID NUMBER : ' . $userPackage->id, 1627, 800, function ($font) {
                $font->file(public_path('font/Adobe-SongTi-Std-L-2.otf'));
                $font->size(100);
                $font->align('center');
                $font->color('#55350A');
            });

            $dateOfPurchase = Carbon::now()->format('d/m/Y');

            $emptyCertificate->text('DATE OF PURCHASE : ' . $dateOfPurchase, 1100, 980, function ($font) {
                $font->file(public_path('font/Adobe-SongTi-Std-L-2.otf'));
                $font->size(74);
                $font->color('#55350A');
            });

            $emptyCertificate->text('PRICE : RM' . $userPackage->price, 1100, 1150, function ($font) {
                $font->file(public_path('font/Adobe-SongTi-Std-L-2.otf'));
                $font->size(74);
                $font->color('#55350A');
            });

            $emptyCertificate->text('UNIT OF GOLD : ' . $userPackage->gram . ' GRAM', 1100, 1320, function ($font) {
                $font->file(public_path('font/Adobe-SongTi-Std-L-2.otf'));
                $font->size(74);
                $font->color('#55350A');
            });

            $emptyCertificate->text('TYPE OF GOLD : 24K GOLD', 1100, 1490, function ($font) {
                $font->file(public_path('font/Adobe-SongTi-Std-L-2.otf'));
                $font->size(74);
                $font->color('#55350A');
            })->save($certificateStoragePath . '/' . $certificateFileName);

            $data['certificate'] = $certificateFileName;


            $userPackage = $this->_userPackageRepository->update($data, $userPackage->id);



            //trading statistic
            $returnProfitPercent = $package->return_profit_percent;
            $returnProfitDays = $package->return_profit_days;
            $percents = [];
            $remainingReturnProfitPercent = $returnProfitPercent;

            while ($returnProfitDays) {
                if (1 < $returnProfitDays--) {
                    //if not a last loop

                    $record = mt_rand(-5 * 10, 5 * 10) / 10;
                    $remainingReturnProfitPercent -= round($record, 2);

                    $percents[] = $record;
                } else {
                    if ($remainingReturnProfitPercent > 5) {
                        //if more than 5%

                        $percents[] = 5;
                        $remainingReturnProfitPercent = round($remainingReturnProfitPercent - 5, 2);
                    } else if ($remainingReturnProfitPercent < -5) {
                        //if less than 5%

                        $percents[] = -5;
                        $remainingReturnProfitPercent = round($remainingReturnProfitPercent + 5, 2);
                    } else {
                        //insert with remaining value
                        $percents[] = round($remainingReturnProfitPercent, 2);
                        $remainingReturnProfitPercent = 0;
                    }
                }
            }

            //if $remainingReturnProfitPercent
            if ($remainingReturnProfitPercent != 0) {
                //find total of target need to be adjust
                $totalAdjustTarget = 0;

                foreach ($percents as $record) {
                    if ($remainingReturnProfitPercent > 0 && $record <= 0) {
                        //if remain value is positive

                        $totalAdjustTarget++;
                    } else if ($remainingReturnProfitPercent < 0 && $record >= 0) {
                        //if remain value is negative

                        $totalAdjustTarget++;
                    }
                }

                //calculate everage how much need to add into each target
                $addValue = $remainingReturnProfitPercent / $totalAdjustTarget;

                //updating the target
                $updatedPercents = [];
                foreach ($percents as $record) {
                    if ($remainingReturnProfitPercent > 0 && $record <= 0) {
                        //if remain value is positive

                        $record += round($addValue, 2);
                    } else if ($remainingReturnProfitPercent < 0 && $record >= 0) {
                        //if remain value is negative

                        $record += round($addValue, 2);
                    }

                    $updatedPercents[] = round($record, 2);
                }
            }

            if (isset($updatedPercents)) {
                if (array_sum($updatedPercents) != $returnProfitPercent) {
                    $adjustValue = $returnProfitPercent - array_sum($updatedPercents);

                    $updatedPercents[1] = $updatedPercents[1] + $adjustValue;
                }
            } else {
                if (array_sum($percents) != $returnProfitPercent) {
                    $adjustValue = $returnProfitPercent - array_sum($percents);

                    $percents[1] = $percents[1] + $adjustValue;
                }
            }

            //insert trading statistic
            $userPackageTradingStatistic = [];
            $currentValue = $package->price;

            for ($i = 0; $i < $package->return_profit_days; $i++) {
                $percent = (isset($updatedPercents) ? $updatedPercents[$i] : $percents[$i]);
                $currentValue += $package->price * ($percent / 100);

                $data['user_trading_statistic']['percent'] = $percent;
                $data['user_trading_statistic']['date'] = Carbon::now()->addDays($i + 1);
                $data['user_trading_statistic']['current_value'] = $currentValue;

                $userPackageTradingStatistic[] = $data['user_trading_statistic'];
            }

            $this->_userPackageTradingRecordRepository->bulkSave($userPackageTradingStatistic, $userPackage->id);


            //update wallet
            $userWallet = $this->_userWalletUserService->getWalletByUserId($data['user_id']);

            if ($userWallet['balance'] < $package->price) {
                array_push($this->_errorMessage, __('user/package.Your_wallet_balance_is_not_enough'));

                DB::rollBack();
                return null;
            }

            $data['user_wallet']['balance'] = $userWallet['balance'] - $package->price;

            $userWallet = $this->_userWalletRepository->update($data['user_wallet'], $userWallet['id']);

            $data['user_wallet_transaction']['user_wallet_id'] = $userWallet->id;
            $data['user_wallet_transaction']['debit'] = null;
            $data['user_wallet_transaction']['credit'] = $package->price;
            $data['user_wallet_transaction']['balance'] = $userWallet->balance;
            $data['user_wallet_transaction']['description'] = "Purchase for investment plan";

            $walletTransaction = $this->_userWalletTransactionRepository->save($data['user_wallet_transaction']);


            //upline commission
            $upline = $this->_userRepository->getById($user->upline_user_id ?? $user->partner_user_id);
            $partnerGroupCommissionLevel = $this->_partnerGroupCommissionLevelUserService->getPartnerGroupCommissionLevel();
            $totalPurchasedCountInReferralGroup = $this->_userPackageRepository->getTotalCountByPartnerUserId($upline->partner_user_id);

            if (!$user->hasRole(UserType::Partner()->key)) {
                $data['user_comission']['user_id'] = $user->upline_user_id;
                $data['user_comission']['downline_user_id'] = $user->id;
                $data['user_comission']['user_package_id'] = $userPackage->id;
                $data['user_comission']['percent'] = 0.00;


                if ($upline->hasRole(UserType::Partner()->key)) {
                    //upline is partner

                    $data['user_comission']['percent'] = 15.00;
                } else if ($upline->hasRole(UserType::AgentOne()->key)) {
                    //upline is agent one

                    if ($partnerGroupCommissionLevel->level == ReferralLevel::One()->key) {
                        $data['user_comission']['percent'] = 5.00;
                    } else if ($partnerGroupCommissionLevel->level == ReferralLevel::Two()->key) {
                        $data['user_comission']['percent'] = 10.00;
                    } else if ($partnerGroupCommissionLevel->level == ReferralLevel::Three()->key) {
                        $data['user_comission']['percent'] = 20.00;
                    }
                } else if ($upline->hasRole(UserType::AgentTwo()->key)) {
                    //upline is agent two (get cashback)

                    $cashbackAmount = 0.00;

                    if ($totalPurchasedCountInReferralGroup <= 3) {
                        $cashbackAmount = 10.00;
                    } else if ($totalPurchasedCountInReferralGroup <= 6) {
                        $cashbackAmount = 25.00;
                    } else if ($totalPurchasedCountInReferralGroup) {
                        $cashbackAmount = 40.00;
                    }


                    $uplineWallet = $this->_userWalletUserService->getWalletByUserId($upline->id);
                    $data['upline_wallet']['balance'] = $uplineWallet['balance'] + $cashbackAmount;

                    $uplineWallet = $this->_userWalletRepository->update($data['upline_wallet'], $uplineWallet['id']);

                    $data['upline_wallet_transaction']['user_wallet_id'] = $uplineWallet->id;
                    $data['upline_wallet_transaction']['debit'] = $cashbackAmount;
                    $data['upline_wallet_transaction']['credit'] = null;
                    $data['upline_wallet_transaction']['balance'] = $uplineWallet->balance;
                    $data['upline_wallet_transaction']['description'] = "Cashback for downline investment plan purchase";

                    $uplineWalletTransaction = $this->_userWalletTransactionRepository->save($data['upline_wallet_transaction']);
                }


                if ($upline->hasRole(UserType::Partner()->key) || $upline->hasRole(UserType::AgentOne()->key)) {
                    $data['user_comission']['amount'] = $userPackage->price * ($data['user_comission']['percent'] / 100);

                    $userCommission = $this->_userCommissionRepository->save($data['user_comission']);
                }
            }


            //upgrate partner group commission level
            if ($partnerGroupCommissionLevel->level == ReferralLevel::One()->key && $totalPurchasedCountInReferralGroup >= 20) {
                $data['partner_group_commission_level']['level'] = ReferralLevel::Two()->key;

                $partnerGroupCommissionLevel = $this->_partnerGroupCommissionLevelUserService->update($data['partner_group_commission_level'], $upline->id);
            } else if ($partnerGroupCommissionLevel->level == ReferralLevel::Two()->key && $totalPurchasedCountInReferralGroup >= 40) {
                $data['partner_group_commission_level']['level'] = ReferralLevel::Three()->key;

                $partnerGroupCommissionLevel = $this->_partnerGroupCommissionLevelUserService->update($data['partner_group_commission_level'], $upline->id);
            }

            DB::commit();
            return $userPackage;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/package.Fail_to_purchase_investment_plan'));
            DB::rollBack();
            return null;
        }
    }

    public function generateFileName()
    {
        return Str::random(5) . Str::uuid() . Str::random(5);
    }

    public function serveCertificate($id)
    {
        try {
            $userPackage = $this->_userPackageRepository->getById($id);

            if (Auth::user() && Auth::id() === $userPackage->user->id) {

                $destinationPath = public_path('storage/user_package_certificate');

                $filepath = $destinationPath . '/' . $userPackage->certificate;
                return response()->file($filepath);
            } else {
                return abort('404');
            }
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to serve certificate.");

            return null;
        }
    }

    public function downloadCertificate($id)
    {
        try {
            $userPackage = $this->_userPackageRepository->getById($id);

            if ($userPackage == null) {
                throw new Exception();
            }

            if (Auth::user() && Auth::id() === $userPackage->user_id) {
                $certificateName = $userPackage->certificate;

                $filePath = public_path('storage/user_package_certificate/' . $certificateName);

                $fileName = "MajuGold-Certificate.jpg";

                return response()->download($filePath, $fileName);
            } else {
                return abort('403');
            }
        } catch (Exception $e) {
            dd($e);
            array_push($this->_errorMessage, __('user/package.Fail_to_download_certificate'));

            return null;
        }
    }
}

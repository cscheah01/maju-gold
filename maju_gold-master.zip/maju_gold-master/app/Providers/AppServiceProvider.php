<?php

namespace App\Providers;

use App\Models\User;
use App\Models\Setting;
use App\Enums\SettingMeta;
use App\Models\UserReview;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        if ($this->app->isLocal()) {
            $this->app->register(\Barryvdh\LaravelIdeHelper\IdeHelperServiceProvider::class);
        }
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer([
            '*'
        ], function () {
            $sliderBarNotice = Setting::where('meta_key', '=', SettingMeta::SliderBarNotice()->key)->first();

            view()->share('sliderBarNotice', $sliderBarNotice);

            $userReviews = UserReview::orderBy('created_at', 'desc')
                ->take(9)
                ->get();

            view()->share('userReviews', $userReviews);
        });
    }
}

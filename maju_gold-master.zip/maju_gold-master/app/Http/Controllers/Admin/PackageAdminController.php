<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\PackageAdminService;

class PackageAdminController extends Controller
{
    private $_packageAdminService;

    public function __construct(PackageAdminService $packageAdminService)
    {
        $this->_packageAdminService = $packageAdminService;
    }

    public function index()
    {
        return view('admin/package/index');
    }

    public function create()
    {
        return view('admin/package/create');
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'image',
            'name',
            'price',
            'gram',
            'return_profit_percent',
            'return_profit_days',
            'is_for_new_user',
        ]);

        $result = $this->_packageAdminService->createPackage($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_packageAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.package.show', $result->id)->with('success', "Package successfully added.");
    }

    public function dataTable()
    {
        $data = $this->_packageAdminService->getDataTable();

        return $data;
    }

    public function show($id)
    {
        $package = $this->_packageAdminService->getById($id);

        if ($package == false) {
            abort(404);
        }

        if ($package == null) {
            $errorMessage = implode("<br>", $this->_packageAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/package/show', compact('package'));
    }

    public function edit($id)
    {
        $package = $this->_packageAdminService->getById($id);

        if ($package == false) {
            abort(404);
        }

        if ($package == null) {
            $errorMessage = implode("<br>", $this->_packageAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/package/edit', compact('package'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'image',
            'name',
            'price',
            'gram',
            'return_profit_percent',
            'return_profit_days',
            'is_for_new_user',
        ]);

        $result = $this->_packageAdminService->update($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_packageAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.package.show',  $result->id)->with('success', "Package details successfully updated.");
    }

    public function destroy($id)
    {
        $result = $this->_packageAdminService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_packageAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.package.index')->with('success', "Package successfully deleted.");
    }
}

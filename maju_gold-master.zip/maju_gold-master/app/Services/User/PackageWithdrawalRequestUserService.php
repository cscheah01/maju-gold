<?php

namespace App\Services\User;

use Exception;
use Carbon\Carbon;
use App\Services\Service;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Repositories\PackageWithdrawalRequestRepository;
use App\Repositories\UserPackageRepository;

class PackageWithdrawalRequestUserService extends Service
{
    protected $_userPackageRepository;
    protected $_packageWithdrawalRequestRepository;

    public function __construct(
        UserPackageRepository $userPackageRepository,
        PackageWithdrawalRequestRepository $packageWithdrawalRequestRepository
    ) {
        $this->_userPackageRepository = $userPackageRepository;
        $this->_packageWithdrawalRequestRepository = $packageWithdrawalRequestRepository;
    }

    public function createPackageWithdrawRequest($id)
    {
        DB::beginTransaction();
        try {
            $package = $this->_userPackageRepository->getById($id);

            $today = Carbon::now()->format('Y-m-d');
            $date = strtotime($package->return_profit_date);
            $date = date('Y-m-d', $date);

            if ($date > $today) {
                array_push($this->_errorMessage, __('user/package.Current_plan_haven_reach_the_maturity_date'));
                throw new Exception();
            }

            $data['user_id'] = Auth::id();
            $data['user_package_id'] = $id;
            $data['is_approved'] = false;

            $packageWithdrawalRequest = $this->_packageWithdrawalRequestRepository->save($data);

            DB::commit();
            return $packageWithdrawalRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/package.Fail_to_send_package_withdrawal_request'));

            DB::rollBack();
            return null;
        }
    }

    public function getPackageWithdrawRequest($userPackageId)
    {
        try {
            $userId = Auth::id();
            $packageWithdrawRequest = $this->_packageWithdrawalRequestRepository->getByUserIdAndUserPackageId($userId, $userPackageId);

            return $packageWithdrawRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/package.Fail_to_get_package_withdrawal_request_details'));

            return null;
        }
    }
}

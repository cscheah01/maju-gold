<?php

namespace App\Services\Admin;

use Exception;
use Carbon\Carbon;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Validator;

class UserAdminService extends Service
{
    protected $_userRepository;

    public function __construct(
        UserRepository $userRepository
    ) {
        $this->_userRepository = $userRepository;
    }

    public function getDataTable()
    {
        $data = DB::table('users')
            ->leftjoin('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->leftjoin('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->select([
                'users.id',
                'users.name',
                'users.email',
                'users.phone_number',
                'users.created_at',
            ])
            ->where('users.deleted_at', '=', null)
            ->where('roles.name', '=', 'user');

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $user = $this->_userRepository->getById($id);

            if ($user == null || $user->hasRole('user') != true) {
                return false;
            }

            return $user;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get user details.");

            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'email' => 'required|string|max:255|unique:users,email,' . $id,
                'ic_passport' => 'required',
                'birthday' => 'date_format:Y-m-d|before:tommorow',
                'phone_number' => 'required|regex:/^(601)[0-46-9][0-9]{7,8}$/|unique:users,phone_number,' . $id,
                'bank_holder_name' => 'nullable|string|max:255',
                'bank_name' => 'nullable|string|max:255',
                'bank_account_number' => 'nullable|numeric',
                'password' => 'nullable|confirmed|min:8'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $user = $this->_userRepository->update($data, $id);

            DB::commit();
            return $user;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update user details.");

            DB::rollBack();
            return null;
        }
    }

    public function getSelectOption($data)
    {
        try {
            $data['result_count'] = 5;
            $data['offset'] = ($data['page'] - 1) * $data['result_count'];

            $productCategories = $this->_userRepository->getAllBySearchTermAndRole($data, 'user');

            $totalCount = $this->_userRepository->getTotalCountBySearchTermAndRole($data, 'user');

            $results = array(
                "results" => $productCategories->toArray(),
                "pagination" => array(
                    "more" => $totalCount < $data['offset'] + $data['result_count'] ? false : true
                )
            );

            return $results;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get user select option list.");

            return null;
        }
    }

    public function getCurrentYearEachMonthNewRegisterUser()
    {
        try {
            $year = Carbon::now()->format('Y');
            $monthlyNewUserCount = $this->_userRepository->getEachMonthTotalCountByYear($year);

            $data = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            foreach ($monthlyNewUserCount as $newUserCount) {
                $data[$newUserCount->month - 1] = $newUserCount->total;
            }

            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get each month new register user count.");

            return null;
        }
    }
}

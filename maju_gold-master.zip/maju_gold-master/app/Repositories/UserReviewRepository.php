<?php

namespace App\Repositories;

use App\Models\UserReview;

class UserReviewRepository extends Repository
{
    protected $_db;

    public function __construct(UserReview $userReview)
    {
        $this->_db = $userReview;
    }

    public function save($data)
    {
        $model = new UserReview;
        $model->name = $data['name'];
        $model->content = $data['content'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->name = $data['name'] ?? $model->name;
        $model->content = $data['content'] ?? $model->content;

        $model->update();
        return $model;
    }
}

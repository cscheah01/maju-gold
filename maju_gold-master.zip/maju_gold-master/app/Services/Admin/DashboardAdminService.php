<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;

class DashboardAdminService extends Service
{
    protected $_packageWithdrawalRequestAdminService;
    protected $_walletWithdrawalRequestAdminService;
    protected $_userAdminService;

    public function __construct(
        PackageWithdrawalRequestAdminService $packageWithdrawalRequestAdminService,
        WalletWithdrawalRequestAdminService $walletWithdrawalRequestAdminService,
        UserAdminService $userAdminService
    ) {
        $this->_packageWithdrawalRequestAdminService = $packageWithdrawalRequestAdminService;
        $this->_walletWithdrawalRequestAdminService = $walletWithdrawalRequestAdminService;
        $this->_userAdminService = $userAdminService;
    }

    public function getData()
    {
        try {
            $data['isms_credit_balance'] = $this->getIsmsCreditBalance();
            $data['pending_package_withdrawal'] = $this->_packageWithdrawalRequestAdminService->getPendingWithdrawalRequestApprovalTotalCount();
            $data['pending_wallet_withdrawal'] = $this->_walletWithdrawalRequestAdminService->getPendingWithdrawalRequestApprovalTotalCount();
            $data['each_month_new_register_user'] = $this->_userAdminService->getCurrentYearEachMonthNewRegisterUser();


            return $data;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get dashboard data.");

            return null;
        }
    }

    public function getIsmsCreditBalance()
    {
        try {
            $endpoint = config('services.isms.endpoint') . '/isms_balance.php';
            $username = urlencode(config('services.isms.username'));
            $password = urlencode(config('services.isms.password'));

            $link = $endpoint . '?un=' . $username . '&pwd=' . $password;
            $http = curl_init($link);

            curl_setopt($http, CURLOPT_RETURNTRANSFER, TRUE);

            $result = curl_exec($http);
            curl_close($http);


            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get balance from ISMS.");

            return null;
        }
    }
}

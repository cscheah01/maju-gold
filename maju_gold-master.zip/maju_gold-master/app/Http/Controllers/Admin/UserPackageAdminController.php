<?php

namespace App\Http\Controllers\Admin;

use App\Enums\UserInvestmentStatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\UserPackageAdminService;
use App\Services\Admin\UserPackageTradingRecordAdminService;

class UserPackageAdminController extends Controller
{
    private $_userPackageAdminService;
    private $_userPackageTradingRecordAdminService;

    private $_userInvestmentStatus;

    public function __construct(
        UserPackageAdminService $userPackageAdminService,
        UserPackageTradingRecordAdminService $userPackageTradingRecordAdminService
    ) {
        $this->_userPackageAdminService = $userPackageAdminService;
        $this->_userPackageTradingRecordAdminService = $userPackageTradingRecordAdminService;

        $this->_userInvestmentStatus = [];
        foreach (UserInvestmentStatus::asArray() as $key => $status) {
            $this->_userInvestmentStatus[] = [
                'value' => $key,
                'description' => UserInvestmentStatus::fromValue($status)->description
            ];
        }
    }

    public function index()
    {
        $userInvestmentStatus = $this->_userInvestmentStatus;
        return view('admin/user_package/index', compact('userInvestmentStatus'));
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'created_at_from',
            'created_at_to',
            'return_profit_date_from',
            'return_profit_date_to',
            'status',
        ]);

        $data = $this->_userPackageAdminService->getDataTable($filterData);

        return $data;
    }

    public function show($id)
    {
        $userPackage = $this->_userPackageAdminService->getById($id);

        if ($userPackage == false) {
            abort(404);
        }

        if ($userPackage == null) {
            $errorMessage = implode("<br>", $this->_userPackageAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        $userPackageTradingRecords = $this->_userPackageTradingRecordAdminService->getPackageTradingRecordByUserPackageId($userPackage['id']);

        return view('admin/user_package/show', compact('userPackage', 'userPackageTradingRecords'));
    }

    public function edit($id)
    {
        $userPackageId = $id;
        $userPackage = $this->_userPackageAdminService->getById($id);
        $userPackageTradingRecords = $this->_userPackageTradingRecordAdminService->getPackageTradingRecordByUserPackageId($userPackageId);

        if ($userPackage == false) {
            abort(404);
        }

        if ($userPackage == null) {
            $errorMessage = implode("<br>", $this->_userPackageTradingRecordAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/user_package/user_package_trading_statistic/edit', compact('userPackage', 'userPackageTradingRecords', 'userPackageId'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'percent',
        ]);

        $result = $this->_userPackageTradingRecordAdminService->update($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userPackageTradingRecordAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.user_package.show',  $result->id)->with('success', "User package trading record successfully updated.");
    }

    public function download($id)
    {
        $result = $this->_userPackageAdminService->downloadCertificate($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userPackageAdminService->_errorMessage);

            return back()->with('error', $errorMessage)->withInput();
        }
        return $result;
    }
}

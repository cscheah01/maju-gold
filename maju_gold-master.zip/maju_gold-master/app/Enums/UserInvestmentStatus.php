<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

final class UserInvestmentStatus extends Enum
{
    const Investing = 0;
    const Withdrawn = 1;
    const PendingWithdrawn = 2;
}

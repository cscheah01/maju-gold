<?php

namespace App\Repositories;

use Carbon\Carbon;
use App\Models\Setting;
use App\Enums\SettingMeta;

class SettingRepository extends Repository
{
    protected $_db;

    public function __construct(Setting $setting)
    {
        $this->_db = $setting;
    }

    public function getByMetaKey($metaKey)
    {
        $data = $this->_db->where('meta_key', '=', $metaKey)->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getAllByMetaKey($metaKey)
    {
        $data = $this->_db->where('meta_key', '=', $metaKey)->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function updateByMetaKey($metaKey, $metaValue)
    {
        $model = $this->_db->where('meta_key', '=', $metaKey)->first();
        $model->meta_value = $metaValue;

        $model->update();
        return $model;
    }

    public function bulkDeleteHomePageBanner($ids)
    {
        $model = $this->_db
            ->whereIn('id', $ids)
            ->where('meta_key', '=', SettingMeta::HomePageBanner()->key)
            ->delete();

        return $model;
    }

    public function bulkSave($data)
    {
        $formatedData = [];

        foreach ($data as $key => $setting) {
            $formatedData[] = [
                'meta_key' => $setting['meta_key'],
                'meta_value' => $setting['meta_value'],
                'created_at' => Carbon::now()->toDateTimeString(),
                'updated_at' => Carbon::now()->toDateTimeString()
            ];
        }

        $this->_db->insert($formatedData);

        return true;
    }
}

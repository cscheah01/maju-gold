<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\User\ProfileUserService;
use App\Services\User\PartnerGroupCommissionLevelUserService;

class ReferralUserController extends Controller
{
    private $_profileUserService;
    private $_partnerGroupCommissionLevelUserService;

    public function __construct(
        ProfileUserService $profileUserService,
        PartnerGroupCommissionLevelUserService $partnerGroupCommissionLevelUserService
    ) {
        $this->_profileUserService = $profileUserService;
        $this->_partnerGroupCommissionLevelUserService = $partnerGroupCommissionLevelUserService;
    }

    public function index()
    {
        $profile = $this->_profileUserService->getProfile();
        $partnerGroupCommissionLevel = $this->_partnerGroupCommissionLevelUserService->getPartnerGroupCommissionLevel();

        return view('user/referral/index', compact('profile', 'partnerGroupCommissionLevel'));
    }
}

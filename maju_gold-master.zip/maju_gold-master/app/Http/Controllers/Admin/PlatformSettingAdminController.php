<?php

namespace App\Http\Controllers\Admin;

use App\Enums\SettingMeta;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\PlatformSettingAdminService;

class PlatformSettingAdminController extends Controller
{
    private $_platformSettingAdminService;

    public function __construct(
        PlatformSettingAdminService $platformSettingAdminService
    ) {
        $this->_platformSettingAdminService = $platformSettingAdminService;
    }

    public function edit()
    {
        $platformSettings = $this->_platformSettingAdminService->getAllPlatformSetting();
        $homePageBanners = $this->_platformSettingAdminService->getAllHomePageBanner();

        return view('admin/platform_setting/edit', compact('platformSettings', 'homePageBanners'));
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'platform_setting',
            'platform_setting.' . SettingMeta::SliderBarNotice()->key,
            'platform_setting.' . SettingMeta::PopUpNotice()->key,
            'platform_setting.home_banner',
            'platform_setting.deleted_home_banner'
        ]);

        $result = $this->_platformSettingAdminService->update($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_platformSettingAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.platform_setting.edit')->with('success', "Platform setting successfully updated.");
    }
}

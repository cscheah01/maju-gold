<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\User\UserWalletUserService;
use App\Services\User\UserPackageUserService;

class ActivityUserController extends Controller
{
    private $_userWalletUserService;
    private $_userPackageUserService;

    public function __construct(
        UserWalletUserService $userWalletUserService,
        UserPackageUserService $userPackageUserService,
    ) {
        $this->_userWalletUserService = $userWalletUserService;
        $this->_userPackageUserService = $userPackageUserService;
    }

    public function index()
    {
        return view('user/activity/index');
    }

    public function walletTransactionDataTable()
    {
        $data = $this->_userWalletUserService->getDataTable();

        return $data;
    }

    public function userPackageTransactionDataTable()
    {
        $data = $this->_userPackageUserService->getDataTable();

        return $data;
    }
}

<?php

namespace App\Services\Admin;

use Image;
use Exception;
use App\Services\Service;
use App\Enums\SettingMeta;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Repositories\SettingRepository;
use Illuminate\Support\Facades\Validator;

class PlatformSettingAdminService extends Service
{
    protected $_settingRepository;

    public function __construct(
        SettingRepository $settingRepository
    ) {
        $this->_settingRepository = $settingRepository;
    }

    public function update($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'platform_setting' => 'required|array',
                'platform_setting.' . SettingMeta::SliderBarNotice()->key => 'nullable|string|max:65,535',
                'platform_setting.' . SettingMeta::PopUpNotice()->key => 'nullable|string|max:65,535',
                'platform_setting.home_banner.*' => 'required|mimes:jpeg,png,jpg',
                'platform_setting.deleted_home_banner.*' => 'required',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }


            if (!empty($data['platform_setting']['deleted_home_banner'])) {
                $this->_settingRepository->bulkDeleteHomePageBanner($data['platform_setting']['deleted_home_banner']);
            }


            if (isset($data['platform_setting']['home_banner']) && !empty($data['platform_setting']['home_banner'])) {
                $data['home_page_banner'] = [];

                foreach ($data['platform_setting']['home_banner'] as $homePageBanner) {
                    $image = $homePageBanner;
                    $fileName = $this->generateFileName();
                    $fileExtension = $homePageBanner->extension();
                    $fileName = $fileName . '.' . $fileExtension;
                    $destinationPath = public_path('storage/home_banner');
                    File::ensureDirectoryExists($destinationPath);

                    $image = Image::make($image->getRealPath());
                    $image->save($destinationPath . '/' . $fileName);

                    $data['home_page_banner'][] = [
                        'meta_key' => SettingMeta::HomePageBanner()->key,
                        'meta_value' => $fileName
                    ];
                }

                $this->_settingRepository->bulkSave($data['home_page_banner']);
            }

            unset($data['platform_setting']['home_banner']);
            unset($data['platform_setting']['deleted_home_banner']);

            foreach ($data['platform_setting'] as $metaKey => $metaValue) {
                $this->_settingRepository->updateByMetaKey($metaKey, $metaValue);
            }

            DB::commit();
            return true;
        } catch (Exception $e) {
            dd($e);
            array_push($this->_errorMessage, "Fail to update platform setting.");
            DB::rollBack();
            return null;
        }
    }

    public function generateFileName()
    {
        return Str::random(5) . Str::uuid() . Str::random(5);
    }

    public function getAllPlatformSetting()
    {
        try {
            $platformSettings = $this->_settingRepository->getAll();

            return $platformSettings;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get platform setting details.");

            return null;
        }
    }

    public function getAllHomePageBanner()
    {
        try {
            $homePageBanners = $this->_settingRepository->getAllByMetaKey(SettingMeta::HomePageBanner()->key);

            return $homePageBanners;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get home page banner list.");

            return null;
        }
    }
}

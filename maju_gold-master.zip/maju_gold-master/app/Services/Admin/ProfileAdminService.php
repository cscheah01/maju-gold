<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class ProfileAdminService extends Service
{
    protected $_userRepository;

    public function __construct(
        UserRepository $userRepository
    ) {
        $this->_userRepository = $userRepository;
    }

    public function getProfile()
    {
        try {
            $id = Auth::id();
            $data = $this->_userRepository->getById($id);

            $profile = $data->toArray();

            return $profile;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get profile details.");

            return null;
        }
    }

    public function updateProfile($data)
    {
        DB::beginTransaction();

        try {
            $id = Auth::id();

            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'email' => 'required|string|max:255|unique:users,email,' . $id,
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $result = $this->_userRepository->update($data, $id);

            DB::commit();
            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update profile details.");

            DB::rollBack();
            return null;
        }
    }

    public function updatePassword($data)
    {
        DB::beginTransaction();

        try {
            $id = Auth::id();
            $user = $this->_userRepository->getById($id);

            $validator = Validator::make($data, [
                'current_password' => ['required', function ($attribute, $value, $fail) use ($user) {
                    if (!Hash::check($value, $user->password)) {
                        return $fail(__('The current password is incorrect.'));
                    }
                }],
                'password' => 'required|confirmed|min:8',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $this->_userRepository->update($data, $id);

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update password.");

            DB::rollBack();
            return null;
        }
    }
}

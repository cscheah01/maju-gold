<?php

namespace App\Repositories;

use App\Models\VerificationCode;


class VerificationCodeRepository extends Repository
{
    protected $_db;

    public function __construct(VerificationCode $verificationCode)
    {
        $this->_db = $verificationCode;
    }

    public function save($data)
    {
        $model = new VerificationCode;
        $model->phone_number = $data['phone_number'];
        $model->otp = encrypt($data['otp']);
        $model->expired_at = $data['expired_at'];

        $model->save();
        return $model->fresh();
    }

    public function getLastByPhoneNumber($phoneNumber)
    {
        $data = $this->_db->where('phone_number', '=', $phoneNumber)
            ->orderBy('created_at', 'desc')
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}

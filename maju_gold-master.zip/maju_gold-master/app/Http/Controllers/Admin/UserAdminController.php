<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\Admin\UserAdminService;
use Illuminate\Support\Facades\Redirect;

class UserAdminController extends Controller
{
    private $_userAdminService;

    public function __construct(UserAdminService $userAdminService)
    {
        $this->_userAdminService = $userAdminService;
    }

    public function index()
    {
        return view('admin/user/index');
    }

    public function dataTable()
    {
        $data = $this->_userAdminService->getDataTable();

        return $data;
    }

    public function show($id)
    {
        $user = $this->_userAdminService->getById($id);

        if ($user == false) {
            abort(404);
        }

        if ($user == null) {
            $errorMessage = implode("<br>", $this->_userAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/user/show', compact('user'));
    }

    public function edit($id)
    {
        $user = $this->_userAdminService->getById($id);

        if ($user == false) {
            abort(404);
        }

        if ($user == null) {
            $errorMessage = implode("<br>", $this->_userAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/user/edit', compact('user'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
            'email',
            'ic_passport',
            'birthday',
            'phone_number',
            'bank_holder_name',
            'bank_name',
            'bank_account_number',
            'password',
            'password_confirmation'
        ]);

        if ($data['password'] == null) {
            unset($data['password']);
        }

        $result = $this->_userAdminService->update($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.user.show',  $result->id)->with('success', "User details successfully updated.");
    }

    public function selectOption(Request $request)
    {
        $data = [
            "search_term" => $request->search_term ?? null,
            "page" => $request->page ?? 1,
        ];

        $results = $this->_userAdminService->getSelectOption($data);

        return $results;
    }
}

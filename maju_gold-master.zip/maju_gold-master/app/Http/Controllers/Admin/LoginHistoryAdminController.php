<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\Admin\LoginHistoryAdminService;

class LoginHistoryAdminController extends Controller
{
    private $_loginHistoryAdminService;

    public function __construct(
        LoginHistoryAdminService $loginHistoryAdminService
    ) {
        $this->_loginHistoryAdminService = $loginHistoryAdminService;
    }
    public function index()
    {
        return view('admin/login_history/index');
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
            'user_id',
        ]);
        $data = $this->_loginHistoryAdminService->getDataTable($filterData);

        return $data;
    }
}

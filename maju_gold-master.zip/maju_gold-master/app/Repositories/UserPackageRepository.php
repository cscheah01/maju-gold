<?php

namespace App\Repositories;

use App\Models\UserPackage;

class UserPackageRepository extends Repository
{
    protected $_db;

    public function __construct(UserPackage $userPackage)
    {
        $this->_db = $userPackage;
    }

    public function save($data)
    {
        $model = new UserPackage;
        $model->user_id = $data['user_id'];
        $model->package_id = $data['package_id'];
        $model->name = $data['name'];
        $model->price = $data['price'];
        $model->gram = $data['gram'];
        $model->return_profit_percent = $data['return_profit_percent'];
        $model->return_profit_days = $data['return_profit_days'];
        $model->return_profit_date = $data['return_profit_date'];
        $model->is_withdrawn = false;
        $model->certificate = $data['certificate'] ?? null;

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->user_id = $data['user_id'] ?? $model->user_id;
        $model->package_id = $data['package_id'] ?? $model->package_id;
        $model->name = $data['name'] ?? $model->name;
        $model->price = $data['price'] ?? $model->price;
        $model->gram = $data['gram'] ?? $model->gram;
        $model->return_profit_percent = $data['return_profit_percent'] ?? $model->return_profit_percent;
        $model->return_profit_days = $data['return_profit_days'] ?? $model->return_profit_days;
        $model->return_profit_date = $data['return_profit_date'] ?? $model->return_profit_date;
        $model->is_withdrawn = $data['is_withdrawn'] ?? $model->is_withdrawn;
        $model->certificate = $data['certificate'] ?? $model->certificate;

        $model->update();
        return $model;
    }

    public function getFirstByUserIdAndIsWithdrawn($userId, $isWithdrawn)
    {
        $data = $this->_db
            ->where('user_id', '=', $userId)
            ->where('is_withdrawn', '=', $isWithdrawn)
            ->first();

        return $data;
    }


    public function getTotalCountByPartnerUserId($partnerUserId)
    {
        $data = $this->_db->leftJoin('users', 'user_packages.user_id', 'users.id')
            ->where('users.partner_user_id', '=', $partnerUserId)
            ->count();

        return $data;
    }
}

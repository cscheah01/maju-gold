<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\StaffAdminService;

class StaffAdminController extends Controller
{
    private $_staffAdminService;

    public function __construct(StaffAdminService $staffAdminService)
    {
        $this->_staffAdminService = $staffAdminService;
    }

    public function index()
    {
        return view('admin/staff/index');
    }

    public function create()
    {
        return view('admin/staff/create');
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'name',
            'email',
            'password',
            'password_confirmation',
        ]);

        $result = $this->_staffAdminService->createStaff($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_staffAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.staff.show', $result->id)->with('success', "Staff successfully added.");
    }

    public function dataTable()
    {
        $data = $this->_staffAdminService->getDataTable();

        return $data;
    }

    public function show($id)
    {
        $staff = $this->_staffAdminService->getById($id);

        if ($staff == false) {
            abort(404);
        }

        if ($staff == null) {
            $errorMessage = implode("<br>", $this->_staffAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/staff/show', compact('staff'));
    }

    public function edit($id)
    {
        $staff = $this->_staffAdminService->getById($id);

        if ($staff == false) {
            abort(404);
        }

        if ($staff == null) {
            $errorMessage = implode("<br>", $this->_staffAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/staff/edit', compact('staff'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
            'email',
            'password',
            'password_confirmation'
        ]);

        if ($data['password'] == null) {
            unset($data['password']);
        }

        $result = $this->_staffAdminService->update($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_staffAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.staff.show',  $result->id)->with('success', "Staff details successfully updated.");
    }

    public function destroy($id)
    {
        if ($id == Auth::id()) {
            return back()->with('error', "You are not allowed to delete own account.");
        }

        $result = $this->_staffAdminService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_staffAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.staff.index')->with('success', "Staff successfully deleted.");
    }
}

<?php

namespace Database\Seeders;

use App\Models\UserWallet;
use Illuminate\Database\Seeder;

class UserWalletSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        UserWallet::create([
            'user_id' => 1,
            'balance' => 0,
        ]);
    }
}

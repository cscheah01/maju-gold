<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

final class CountryOption extends Enum
{
    const Malaysia = 0;
    const Singapore = 1;
}

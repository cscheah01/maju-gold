<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PackageWithdrawalRequest extends Model
{
    use HasFactory;

    public function userPackage()
    {
        return $this->belongsTo(UserPackage::class, 'user_package_id', 'id');
    }

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}

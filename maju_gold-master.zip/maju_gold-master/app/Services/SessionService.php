<?php

namespace App\Services;

use Exception;
use App\Enums\LanguageType;
use Illuminate\Support\Facades\App;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class SessionService extends Service
{
    protected $_userRepository;

    public function __construct(
        UserRepository $userRepository
    ) {
        $this->_userRepository = $userRepository;
    }

    public function updateUserLanguage($data)
    {
        try {
            $validator = Validator::make($data, [
                'language' => 'required|in:' . implode(",", LanguageType::getKeys()),
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            Session::put('language', $data['language']);
            App::setLocale($data['language']);

            if (Auth::check()) {
                $this->_userRepository->update($data, Auth::id());
            }

            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to switch language.");

            return null;
        }
    }
}

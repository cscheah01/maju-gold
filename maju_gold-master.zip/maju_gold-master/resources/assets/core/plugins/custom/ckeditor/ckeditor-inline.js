// CKEditor  - Rock-solid, free WYSIWYG editor with collaborative editing, 200+ features, full documentation and support: https://ckeditor.com/

// CKEditor Inline
window.InlineEditor = require('@ckeditor/ckeditor5-build-inline/build/ckeditor.js');

<?php

namespace App\Services;

use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Stevebauman\Location\Facades\Location;
use App\Repositories\LoginHistoryRepository;

class LoginHistoryService extends Service
{
    protected $_loginHistoryRepository;

    public function __construct(
        LoginHistoryRepository $loginHistoryRepository
    ) {
        $this->_loginHistoryRepository = $loginHistoryRepository;
    }

    public function createLoginHistory()
    {
        DB::beginTransaction();
        try {
            $locationData = Location::get();
            $userId = Auth::id();

            $data['ip_address'] = $locationData->ip;
            $data['country_name'] = $locationData->countryName;
            $data['user_id'] = $userId;

            $loginHistory = $this->_loginHistoryRepository->save($data);

            DB::commit();
            return $loginHistory;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to save login history.");
            DB::rollBack();
            return null;
        }
    }
}

<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\Admin\WalletWithdrawalRequestAdminService;

class WalletWithdrawalRequestAdminController extends Controller
{
    private $_walletWithdrawalRequestAdminService;

    public function __construct(
        WalletWithdrawalRequestAdminService $walletWithdrawalRequestAdminService
    ) {
        $this->_walletWithdrawalRequestAdminService = $walletWithdrawalRequestAdminService;
    }

    public function index()
    {
        return view('admin/wallet_withdrawal_request/index');
    }

    public function show($id)
    {
        $walletWithdrawalRequest = $this->_walletWithdrawalRequestAdminService->getById($id);

        if ($walletWithdrawalRequest == false) {
            abort(404);
        }

        if ($walletWithdrawalRequest == null) {
            $errorMessage = implode("<br>", $this->_walletWithdrawalRequestAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/wallet_withdrawal_request/show', compact('walletWithdrawalRequest'));
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
        ]);

        $data = $this->_walletWithdrawalRequestAdminService->getDataTable($filterData);

        return $data;
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'is_approved',
            'remark'
        ]);

        $result = $this->_walletWithdrawalRequestAdminService->update($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_walletWithdrawalRequestAdminService->_errorMessage);

            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "User wallet withdrawal request successfully updated.");
    }
}

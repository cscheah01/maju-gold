<?php

namespace App\Repositories;

use App\Models\Package;

class PackageRepository extends Repository
{
    protected $_db;

    public function __construct(Package $package)
    {
        $this->_db = $package;
    }

    public function save($data)
    {
        $model = new Package;
        $model->name = $data['name'];
        $model->image = $data['image'] ?? null;
        $model->price = $data['price'];
        $model->gram = $data['gram'];
        $model->return_profit_percent = $data['return_profit_percent'];
        $model->return_profit_days = $data['return_profit_days'];
        $model->is_for_new_user = $data['is_for_new_user'];

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->name = $data['name'] ?? $model->name;
        $model->image = ($data['image'] ?? false) ? $data['image'] : $model->image;
        $model->price = $data['price'] ?? $model->price;
        $model->gram = $data['gram'] ?? $model->gram;
        $model->return_profit_percent = $data['return_profit_percent'] ?? $model->return_profit_percent;
        $model->return_profit_days = $data['return_profit_days'] ?? $model->return_profit_days;
        $model->is_for_new_user = $data['is_for_new_user'] ?? $model->is_for_new_user;

        $model->update();
        return $model;
    }

    public function getAllPackageExcludeNewUserPackage()
    {
        $data = $this->_db
            ->where('is_for_new_user', '=', false)
            ->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}

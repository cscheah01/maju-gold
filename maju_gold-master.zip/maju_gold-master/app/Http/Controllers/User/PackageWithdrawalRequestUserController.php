<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\User\PackageWithdrawalRequestUserService;

class PackageWithdrawalRequestUserController extends Controller
{
    private $_packageWithdrawalRequestUserService;

    public function __construct(
        PackageWithdrawalRequestUserService $packageWithdrawalRequestUserService,
    ) {
        $this->_packageWithdrawalRequestUserService = $packageWithdrawalRequestUserService;
    }

    public function withdraw($id)
    {
        $result = $this->_packageWithdrawalRequestUserService->createPackageWithdrawRequest($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_packageWithdrawalRequestUserService->_errorMessage);

            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success',  __('user/package.Investment_plan_withdrawal_request_successfully_sent'));
    }
}

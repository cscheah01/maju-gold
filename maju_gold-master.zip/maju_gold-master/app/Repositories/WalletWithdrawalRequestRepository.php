<?php

namespace App\Repositories;

use App\Models\WalletWithdrawalRequest;

class WalletWithdrawalRequestRepository extends Repository
{
    protected $_db;

    public function __construct(WalletWithdrawalRequest $walletWithdrawalRequest)
    {
        $this->_db = $walletWithdrawalRequest;
    }

    public function save($data)
    {
        $model = new WalletWithdrawalRequest;
        $model->user_id = $data['user_id'];
        $model->user_wallet_id = $data['user_wallet_id'];
        $model->amount = $data['amount'];
        $model->is_approved = false;
        $model->is_rejected = false;
        $model->remark = $data['remark'] ?? null;

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->user_id = $data['user_id'] ?? $model->user_id;
        $model->user_wallet_id = $data['user_wallet_id'] ?? $model->user_wallet_id;
        $model->amount = $data['amount'] ?? $model->amount;
        $model->is_approved = $data['is_approved'] ?? $model->is_approved;
        $model->is_rejected = $data['is_rejected'] ?? $model->is_rejected;
        $model->remark = $data['remark'] ?? $model->remark;

        $model->update();
        return $model;
    }

    public function getPendingApprovalTotalCount()
    {
        $data = $this->_db
            ->where('is_approved', '=', false)
            ->where('is_rejected', '=', false)
            ->count();

        return $data;
    }
}

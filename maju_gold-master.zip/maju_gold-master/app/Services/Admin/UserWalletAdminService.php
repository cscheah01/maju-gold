<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\UserWalletRepository;
use App\Repositories\UserWalletTransactionRepository;

class UserWalletAdminService extends Service
{
    protected $_userWalletRepository;
    protected $_userWalletTransactionRepository;

    public function __construct(
        UserWalletRepository $userWalletRepository,
        UserWalletTransactionRepository $userWalletTransactionRepository
    ) {
        $this->_userWalletRepository = $userWalletRepository;
        $this->_userWalletTransactionRepository = $userWalletTransactionRepository;
    }

    public function getDataTable()
    {
        $data = DB::table('user_wallets')
            ->leftjoin('users', 'user_wallets.user_id', '=', 'users.id')
            ->select([
                'user_wallets.id',
                'user_wallets.balance',
                'users.id as user_id',
                'users.name as user_name',
                'users.email as user_email',
                'users.phone_number as user_phone_number',
            ]);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $userWallet = $this->_userWalletRepository->getById($id);

            if ($userWallet == null) {
                return false;
            }

            return $userWallet;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get user wallet details.");

            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'amount' => 'required|numeric|between: 0.01,99999999999.99',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userWallet = $this->_userWalletRepository->getById($id);

            $data['balance'] = $userWallet->balance + $data['amount'];

            $user = $this->_userWalletRepository->update($data, $id);

            $data['user_wallet_transaction']['user_wallet_id'] = $id;
            $data['user_wallet_transaction']['debit'] = $data['amount'];
            $data['user_wallet_transaction']['balance'] = $data['balance'];
            $data['user_wallet_transaction']['description'] = "Top up by staff";

            $this->_userWalletTransactionRepository->save($data['user_wallet_transaction']);

            DB::commit();
            return $user;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update user wallet.");

            DB::rollBack();
            return null;
        }
    }

    public function getTransactionDataTable($id)
    {
        $wallet = $this->_userWalletRepository->getById($id);

        $data = DB::table('user_wallet_transactions')
            ->select([
                'user_wallet_transactions.debit',
                'user_wallet_transactions.credit',
                'user_wallet_transactions.balance',
                'user_wallet_transactions.description',
                'user_wallet_transactions.created_at',
            ])
            ->where('user_wallet_transactions.user_wallet_id', '=', $wallet->id);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }
}

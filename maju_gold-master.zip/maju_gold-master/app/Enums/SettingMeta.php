<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

final class SettingMeta extends Enum
{
    const SliderBarNotice = 0;
    const PopUpNotice = 1;
    const HomePageBanner = 2;
}

<?php

namespace App\Services\User;

use Exception;
use App\Services\Service;
use App\Enums\ReferralLevel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Repositories\PartnerGroupCommissionLevelRepository;

class PartnerGroupCommissionLevelUserService extends Service
{
    protected $_partnerGroupCommissionLevelRepository;

    public function __construct(
        PartnerGroupCommissionLevelRepository $partnerGroupCommissionLevelRepository
    ) {
        $this->_partnerGroupCommissionLevelRepository = $partnerGroupCommissionLevelRepository;
    }

    public function getPartnerGroupCommissionLevel()
    {
        try {
            $user = Auth::user();

            $partnerGroupCommissionLevel = $this->_partnerGroupCommissionLevelRepository->getByPartnerUserId($user['partner_user_id']);

            return $partnerGroupCommissionLevel;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/referral.Fail_to_get_partner_group_commission_level_details'));

            return null;
        }
    }

    public function update($data, $partnerUserId)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'level' => 'required|in:' . implode(",", ReferralLevel::getKeys()),
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $partnerGroupCommissionLevelRepository = $this->_partnerGroupCommissionLevelRepository->updateByPartnerUserId($data, $partnerUserId);

            DB::commit();
            return $partnerGroupCommissionLevelRepository;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/referral.Fail_to_update_partner_group_commission_level'));

            DB::rollBack();
            return null;
        }
    }
}

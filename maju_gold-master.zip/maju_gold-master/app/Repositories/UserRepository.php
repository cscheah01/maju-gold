<?php

namespace App\Repositories;

use App\Models\User;
use App\Enums\LanguageType;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class UserRepository extends Repository
{
    protected $_db;

    public function __construct(User $user)
    {
        $this->_db = $user;
    }

    public function save($data)
    {
        $model = new User;
        $model->name = $data['name'];
        $model->email = $data['email'];
        $model->ic_passport = $data['ic_passport'] ?? null;
        $model->phone_number = $data['phone_number'] ?? null;
        $model->birthday = $data['birthday'] ?? null;
        $model->password = Hash::make($data['password']);
        $model->language = $data['language'] ?? LanguageType::En()->key;
        $model->code = $data['code'] ?? null;
        $model->partner_user_id = $data['partner_user_id'] ?? null;
        $model->upline_user_id = $data['upline_user_id'] ?? null;
        $model->bank_holder_name = $data['bank_holder_name'] ?? null;
        $model->bank_name = $data['bank_name'] ?? null;
        $model->bank_account_number = $data['bank_account_number'] ?? null;

        $model->save();
        return $model->fresh();
    }


    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->name = $data['name'] ?? $model->name;
        $model->email = $data['email'] ?? $model->email;
        $model->ic_passport = $data['ic_passport'] ?? $model->ic_passport;
        $model->phone_number = $data['phone_number'] ?? $model->phone_number;
        $model->birthday = $data['birthday'] ?? $model->birthday;
        $model->password = ($data['password'] ?? false) ? Hash::make($data['password']) : $model->password;
        $model->language = $data['language'] ?? $model->language;
        $model->code = $data['code'] ?? $model->code;
        $model->partner_user_id = $data['partner_user_id'] ?? $model->partner_user_id;
        $model->upline_user_id = $data['upline_user_id'] ?? $model->upline_user_id;
        $model->bank_holder_name = $data['bank_holder_name'] ?? $model->bank_holder_name;
        $model->bank_name = $data['bank_name'] ?? $model->bank_name;
        $model->bank_account_number = $data['bank_account_number'] ?? $model->bank_account_number;

        $model->update();
        return $model;
    }

    public function getByCode($code)
    {
        $data = $this->_db
            ->where('code', '=', $code)
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getByPhoneNumber($phoneNumber)
    {
        $data = $this->_db
            ->where('phone_number', '=', $phoneNumber)
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getAllBySearchTermAndRole($data, $role)
    {
        $name = $data['search_term'] ?? '';

        $data = $this->_db
            ->leftjoin('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->leftjoin('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->select("users.id", "users.name")
            ->where('roles.name', '=', $role)
            ->where('users.name', 'LIKE', "%$name%")
            ->skip($data['offset'])->take($data['result_count'])
            ->get();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getTotalCountBySearchTermAndRole($data, $role)
    {
        $name = $data['search_term'] ?? '';

        $totalCount = $this->_db
            ->leftjoin('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->leftjoin('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->where('roles.name', '=', $role)
            ->where('users.name', 'LIKE', "%$name%")
            ->count();

        return $totalCount;
    }

    public function getEachMonthTotalCountByYear($year)
    {
        $data = $this->_db->select(DB::raw('COUNT(*) as total,MONTH(users.created_at) as month'))
            ->leftjoin('model_has_roles', 'users.id', '=', 'model_has_roles.model_id')
            ->leftjoin('roles', 'model_has_roles.role_id', '=', 'roles.id')
            ->whereYear('users.created_at', '=', $year)
            ->where('roles.name', '=', 'user')
            ->groupBy(DB::raw('MONTH(users.created_at)'))
            ->get();


        return $data;
    }
}

<?php

namespace App\Services\Admin;

use App\Repositories\UserWalletRepository;
use App\Repositories\UserWalletTransactionRepository;
use Exception;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\WalletWithdrawalRequestRepository;

class WalletWithdrawalRequestAdminService extends Service
{
    protected $_walletWithdrawalRequestRepository;
    protected $_userWalletRepository;
    protected $_userWalletTransactionRepository;

    public function __construct(
        WalletWithdrawalRequestRepository $walletWithdrawalRequestRepository,
        UserWalletRepository $userWalletRepository,
        UserWalletTransactionRepository $userWalletTransactionRepository
    ) {
        $this->_walletWithdrawalRequestRepository = $walletWithdrawalRequestRepository;
        $this->_userWalletRepository = $userWalletRepository;
        $this->_userWalletTransactionRepository = $userWalletTransactionRepository;
    }

    public function getDataTable($filterData)
    {
        $data = DB::table('wallet_withdrawal_requests')
            ->leftjoin('users', 'wallet_withdrawal_requests.user_id', '=', 'users.id')
            ->select([
                'wallet_withdrawal_requests.id',
                'wallet_withdrawal_requests.user_id',
                'wallet_withdrawal_requests.amount',
                'wallet_withdrawal_requests.is_approved',
                'wallet_withdrawal_requests.is_rejected',
                'wallet_withdrawal_requests.created_at',
                'users.name as user_name',
                'users.phone_number as user_phone_number',
            ]);

        if (!empty($filterData['date_from'])) {
            $data->where('wallet_withdrawal_requests.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('wallet_withdrawal_requests.created_at', '<=', $filterData['date_to']);
        }

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->getById($id);

            if ($walletWithdrawalRequest == null) {
                return false;
            }

            return $walletWithdrawalRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get wallet withdrawal request details.");

            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'is_approved' => 'required|boolean',
                'remark' => 'nullable|required_if:is_approved,==,false|string|max:255'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->getById($id);

            if ($walletWithdrawalRequest->is_approved || $walletWithdrawalRequest->is_rejected) {
                throw new Exception();
            }

            if ($data['is_approved']) {
                $data['is_rejected'] = false;

                $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->update($data, $id);

                $userWallet = $this->_userWalletRepository->getById($walletWithdrawalRequest->user_wallet_id);

                $data['user_wallet_transaction']['user_wallet_id'] = $walletWithdrawalRequest->user_wallet_id;
                $data['user_wallet_transaction']['balance'] = $userWallet->balance;
                $data['user_wallet_transaction']['description'] = 'Withdraw request aproaved by staff';

                $this->_userWalletTransactionRepository->save($data['user_wallet_transaction']);
            } else {
                $data['is_rejected'] = true;
                $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->update($data, $id);

                $userWallet = $this->_userWalletRepository->getById($walletWithdrawalRequest->user_wallet_id);

                $data['wallet']['balance'] = $userWallet->balance + $walletWithdrawalRequest->amount;

                $userWallet = $this->_userWalletRepository->update($data['wallet'], $walletWithdrawalRequest->user_wallet_id);

                $data['user_wallet_transaction']['user_wallet_id'] = $walletWithdrawalRequest->user_wallet_id;
                $data['user_wallet_transaction']['balance'] = $data['wallet']['balance'];
                $data['user_wallet_transaction']['debit'] = $walletWithdrawalRequest->amount;
                $data['user_wallet_transaction']['description'] = 'Withdraw request rejected by staff, Reason: ' . $data['remark'];

                $this->_userWalletTransactionRepository->save($data['user_wallet_transaction']);
            }

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update withdrawal request.");

            DB::rollBack();
            return null;
        }
    }

    public function getPendingWithdrawalRequestApprovalTotalCount()
    {
        try {
            $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->getPendingApprovalTotalCount();

            return $walletWithdrawalRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get total pending wallet withdrawal request approval count.");

            return null;
        }
    }
}

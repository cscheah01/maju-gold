<?php

namespace Database\Seeders;

use App\Enums\ReferralLevel;
use App\Models\PartnerGroupCommissionLevel;
use Illuminate\Database\Seeder;

class PartnerGroupCommissionLevelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        PartnerGroupCommissionLevel::create([
            'partner_user_id' => 1,
            'level' => ReferralLevel::One()->key,
        ]);
    }
}

<?php

namespace App\Repositories;

use App\Models\PackageWithdrawalRequest;

class PackageWithdrawalRequestRepository extends Repository
{
    protected $_db;

    public function __construct(PackageWithdrawalRequest $packageWithdrawalRequest)
    {
        $this->_db = $packageWithdrawalRequest;
    }

    public function save($data)
    {
        $model = new PackageWithdrawalRequest;
        $model->user_id = $data['user_id'];
        $model->user_package_id = $data['user_package_id'];
        $model->is_approved = $data['is_approved'];
        $model->remark = $data['remark'] ?? null;

        $model->save();
        return $model->fresh();
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->user_id = $data['user_id'] ?? $model->user_id;
        $model->user_package_id = $data['user_package_id'] ?? $model->user_package_id;
        $model->is_approved = $data['is_approved'] ?? $model->is_approved;
        $model->remark = $data['remark'] ?? $model->remark;

        $model->update();
        return $model;
    }

    public function getByUserIdAndUserPackageId($userId, $userPackageId)
    {
        $data = $this->_db->where('user_id', '=', $userId)
            ->where('user_package_id', '=', $userPackageId)->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getAllById($id)
    {
        $data = $this->_db->find($id)
            ->select('package_withdrawal_requests.*', 'user_package_trading_records.current_value')
            ->leftJoin('user_packages', 'package_withdrawal_requests.user_package_id', 'user_packages.id')
            ->leftJoin('user_package_trading_records', function ($query) {
                $query->on('user_packages.id', '=', 'user_package_trading_records.user_package_id')
                    ->whereRaw('user_package_trading_records.id IN (select MAX(user_package_trading_records.id) from user_package_trading_records join user_packages on user_packages.id = user_package_trading_records.user_package_id group by user_package_trading_records.user_package_id)');
            })
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }

    public function getPendingApprovalTotalCount()
    {
        $data = $this->_db
            ->where('is_approved', '=', false)
            ->count();

        return $data;
    }
}

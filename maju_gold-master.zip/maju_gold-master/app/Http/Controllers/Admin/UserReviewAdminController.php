<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\UserReviewAdminService;

class UserReviewAdminController extends Controller
{
    private $_userReviewAdminService;

    public function __construct(
        UserReviewAdminService $userReviewAdminService
    ) {
        $this->_userReviewAdminService = $userReviewAdminService;
    }

    public function index()
    {
        return view('admin/user_review/index');
    }

    public function dataTable()
    {
        $data = $this->_userReviewAdminService->getDataTable();

        return $data;
    }

    public function create()
    {
        return view('admin/user_review/create');
    }

    public function store(Request $request)
    {
        $data = $request->only([
            'name',
            'content',
        ]);

        $result = $this->_userReviewAdminService->createReview($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userReviewAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.user_review.show', $result->id)->with('success', "User Review successfully added.");
    }

    public function show($id)
    {
        $userReview = $this->_userReviewAdminService->getById($id);

        if ($userReview == false) {
            abort(404);
        }

        if ($userReview == null) {
            $errorMessage = implode("<br>", $this->_userReviewAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/user_review/show', compact('userReview'));
    }

    public function edit($id)
    {
        $userReview = $this->_userReviewAdminService->getById($id);

        if ($userReview == false) {
            abort(404);
        }

        if ($userReview == null) {
            $errorMessage = implode("<br>", $this->_userReviewAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/user_review/edit', compact('userReview'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'name',
            'content',
        ]);

        $result = $this->_userReviewAdminService->update($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userReviewAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.user_review.show',  $result->id)->with('success', "User review successfully updated.");
    }

    public function destroy($id)
    {
        $result = $this->_userReviewAdminService->deleteById($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userReviewAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.user_review.index')->with('success', "User review successfully deleted.");
    }
}

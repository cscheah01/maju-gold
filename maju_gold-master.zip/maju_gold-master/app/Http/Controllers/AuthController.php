<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Enums\OtpRequestType;
use App\Services\AuthService;
use Illuminate\Support\Facades\Auth;
use App\Services\PlatformSettingService;
use Illuminate\Support\Facades\Redirect;

class AuthController extends Controller
{
    private $_authService;
    private $_platformSettingService;

    public function __construct(
        AuthService $authService,
        PlatformSettingService $platformSettingService
    ) {
        $this->_authService = $authService;
        $this->_platformSettingService = $platformSettingService;
    }

    public function loginIndex()
    {
        $popUpNotice = $this->_platformSettingService->getPopUpNotice();

        return view('public/auth/login', compact('popUpNotice'));
    }

    public function login(Request $request)
    {
        $data = $request->only([
            'email',
            'password',
        ]);

        $result = $this->_authService->loginUser($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_authService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        if (Auth::user()->hasRole('admin')) {
            return Redirect::route('admin.dashboard');
        } else if (Auth::user()->hasRole('user')) {
            return Redirect::route('user.dashboard');
        }

        return Redirect::route('user.dashboard');
    }

    public function logout()
    {
        $result = $this->_authService->logoutUser();

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_authService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('login.index');
    }

    public function registerIndex(Request $request)
    {
        $referralCode = $request->query('referral_code', null);

        return view('public/auth/register', compact('referralCode'));
    }

    public function register(Request $request)
    {
        $data = $request->only([
            'name',
            'ic_passport',
            'password',
            'password_confirmation',
            'birthday',
            'referral_code',
            'email',
            'bank_name',
            'bank_holder_name',
            'bank_account_number',
            'country',
            'phone_number',
            'sms_otp',
        ]);

        $result = $this->_authService->registerUser($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_authService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('login.index')->with('success', "Successfully registered.");
    }

    public function requestOtp(Request $request)
    {
        $data = $request->only([
            'phone_number',
        ]);

        $result = $this->_authService->sendOtp($data, OtpRequestType::Register());

        return $result;
    }

    public function requestResetOtp(Request $request)
    {
        $data = $request->only([
            'phone_number',
        ]);

        $result = $this->_authService->sendOtp($data, OtpRequestType::ResetPassword());

        return $result;
    }


    public function forgotPasswordIndex()
    {
        return view('public/auth/forgot-password');
    }

    public function resetPassword(Request $request)
    {
        $data = $request->only([
            'phone_number',
            'sms_otp',
            'password',
            'password_confirmation',
        ]);

        $result = $this->_authService->resetUserPassword($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_authService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('login.index')->with('success', "Your account password successfully reset.");
    }
}

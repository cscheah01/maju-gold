<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\UserPackageRepository;
use App\Repositories\PackageWithdrawalRequestRepository;

class PackageWithdrawalRequestAdminService extends Service
{
    protected $_packageWithdrawalRequestRepository;
    protected $_userPackageRepository;


    public function __construct(
        PackageWithdrawalRequestRepository $packageWithdrawalRequestRepository,
        UserPackageRepository $userPackageRepository
    ) {
        $this->_packageWithdrawalRequestRepository = $packageWithdrawalRequestRepository;
        $this->_userPackageRepository = $userPackageRepository;
    }

    public function getDataTable($filterData)
    {
        $data = DB::table('package_withdrawal_requests')
            ->leftjoin('users', 'package_withdrawal_requests.user_id', '=', 'users.id')
            ->leftJoin('user_packages', 'package_withdrawal_requests.user_package_id', 'user_packages.id')
            ->leftJoin('user_package_trading_records', function ($query) {
                $query->on('user_packages.id', '=', 'user_package_trading_records.user_package_id')
                    ->whereRaw('user_package_trading_records.id IN (select MAX(user_package_trading_records.id) from user_package_trading_records join user_packages on user_packages.id = user_package_trading_records.user_package_id group by user_package_trading_records.user_package_id)');
            })
            ->select([
                'package_withdrawal_requests.id',
                'package_withdrawal_requests.user_id',
                'package_withdrawal_requests.is_approved',
                'package_withdrawal_requests.created_at',
                'package_withdrawal_requests.remark',
                'user_packages.name as package_name',
                'users.name as user_name',
                'users.phone_number as user_phone_number',
                'user_package_trading_records.current_value',
            ]);

        if (!empty($filterData['date_from'])) {
            $data->where('package_withdrawal_requests.created_at', '>=', $filterData['date_from']);
        }

        if (!empty($filterData['date_to'])) {
            $data->where('package_withdrawal_requests.created_at', '<=', $filterData['date_to']);
        }

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $packageWithdrawalRequest = $this->_packageWithdrawalRequestRepository->getAllById($id);

            if ($packageWithdrawalRequest == null) {
                return false;
            }

            return $packageWithdrawalRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get investment withdrawal request details.");

            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'is_approved' => 'required|boolean',
                'remark' => 'nullable|string|max:255'
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $packageWithdrawalRequest = $this->_packageWithdrawalRequestRepository->getById($id);

            if ($packageWithdrawalRequest->is_approved) {
                throw new Exception();
            }

            $packageWithdrawalRequest = $this->_packageWithdrawalRequestRepository->update($data, $id);

            if ($data['is_approved']) {
                $data['user_package'] = ['is_withdrawn' => true];
                $userPackage = $this->_userPackageRepository->update($data['user_package'], $packageWithdrawalRequest->user_package_id);
            }

            DB::commit();
            return $packageWithdrawalRequest;
        } catch (Exception $e) {
            dd($e);
            array_push($this->_errorMessage, "Fail to update investment withdrawal request.");

            DB::rollBack();
            return null;
        }
    }

    public function getPendingWithdrawalRequestApprovalTotalCount()
    {
        try {
            $packageWithdrawalRequest = $this->_packageWithdrawalRequestRepository->getPendingApprovalTotalCount();

            return $packageWithdrawalRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get total pending investment withdrawal request approval count.");

            return null;
        }
    }
}

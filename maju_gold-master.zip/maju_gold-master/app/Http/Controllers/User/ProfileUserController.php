<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\User\ProfileUserService;

class ProfileUserController extends Controller
{
    private $_profileUserService;

    public function __construct(ProfileUserService $profileUserService)
    {
        $this->_profileUserService = $profileUserService;
    }

    public function index()
    {
        return view('user/profile/index');
    }

    public function update(Request $request)
    {
        $data = $request->only([
            'name',
            'email',
            'ic_passport',
            'birthday',
            'bank_holder_name',
            'bank_name',
            'bank_account_number',
        ]);

        $result = $this->_profileUserService->updateProfile($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_profileUserService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('user.profile.index')->with('success',  __('user/profile.Profile_details_successfully_updated'));
    }

    public function edit()
    {
        return view('user/profile/edit');
    }

    public function editPassword()
    {
        return view('user/profile/password/edit');
    }

    public function updatePassword(Request $request)
    {
        $data = $request->only([
            'current_password',
            'password',
            'password_confirmation',
        ]);

        $result = $this->_profileUserService->updatePassword($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_profileUserService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', __('user/profile.Password_successfully_updated'));
    }
}

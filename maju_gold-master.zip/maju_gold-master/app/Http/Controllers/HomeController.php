<?php

namespace App\Http\Controllers;

use App\Services\PlatformSettingService;

class HomeController extends Controller
{
    private $_platformSettingService;

    public function __construct(
        PlatformSettingService $platformSettingService
    ) {
        $this->_platformSettingService = $platformSettingService;
    }

    public function index()
    {
        $homePageBanners = $this->_platformSettingService->getAllHomePageBanner();

        return view('public/home/index', compact('homePageBanners'));
    }
}

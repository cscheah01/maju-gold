<?php

namespace App\Services;

class Service
{
    public $_errorMessage = array();
}

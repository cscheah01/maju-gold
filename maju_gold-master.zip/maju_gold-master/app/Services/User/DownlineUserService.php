<?php

namespace App\Services\User;

use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class DownlineUserService extends Service
{
    public function getDataTable()
    {
        $userId = Auth::id();

        $data = DB::table('users')
            ->select([
                'users.name',
                'users.email',
                'users.phone_number',
                'users.created_at',
            ])
            ->where('users.deleted_at', '=', null)
            ->where('users.upline_user_id', '=', $userId);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }
}

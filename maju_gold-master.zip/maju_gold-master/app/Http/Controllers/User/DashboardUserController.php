<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Services\User\UserWalletUserService;
use App\Services\User\UserPackageUserService;

class DashboardUserController extends Controller
{
    private $_userWalletUserService;
    private $_userPackageUserService;

    public function __construct(
        UserWalletUserService $userWalletUserService,
        UserPackageUserService $userPackageUserService
    ) {
        $this->_userWalletUserService = $userWalletUserService;
        $this->_userPackageUserService = $userPackageUserService;
    }

    public function index()
    {
        $userId = Auth::id();

        $wallet = $this->_userWalletUserService->getWalletByUserId($userId);
        $package = $this->_userPackageUserService->getCurrentPackage($userId);

        return view('user/dashboard/index', compact('wallet', 'package'));
    }
}

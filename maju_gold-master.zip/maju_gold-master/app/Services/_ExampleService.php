<?php

namespace App\Services;

use Exception;
use App\Services\Service;

class ExampleService extends Service
{

    public function __construct() {
        //
    }

    
}

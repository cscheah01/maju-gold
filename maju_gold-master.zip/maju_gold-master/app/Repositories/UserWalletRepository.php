<?php

namespace App\Repositories;

use App\Models\UserWallet;

class UserWalletRepository extends Repository
{
    protected $_db;

    public function __construct(UserWallet $userWallet)
    {
        $this->_db = $userWallet;
    }

    public function save($data)
    {
        $model = new UserWallet;
        $model->user_id = $data['user_id'];
        $model->balance = $data['balance'] ?? 0;

        $model->save();
        return $model->fresh();
    }

    public function updateByUserId($data, $userId)
    {
        $model = $this->_db->where('user_id', '=', $userId)->first();
        $model->balance = $data['balance'] ?? $model->balance;

        $model->update();
        return $model;
    }

    public function update($data, $id)
    {
        $model = $this->_db->find($id);
        $model->balance = $data['balance'] ?? $model->balance;

        $model->update();
        return $model;
    }

    public function getByUserId($userId)
    {
        $data = $this->_db->where('user_id', '=', $userId)
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}

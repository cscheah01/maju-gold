<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('ic_passport')->nullable();
            $table->string('phone_number')->nullable()->unique();
            $table->date('birthday')->nullable();
            $table->string('password');
            $table->string('language');
            $table->string('code')->nullable()->unique();
            $table->unsignedBigInteger('partner_user_id')->nullable();
            $table->foreign('partner_user_id')->references('id')->on('users');
            $table->unsignedBigInteger('upline_user_id')->nullable();
            $table->foreign('upline_user_id')->references('id')->on('users');
            $table->string('bank_holder_name')->nullable();
            $table->string('bank_name')->nullable();
            $table->string('bank_account_number')->nullable();
            $table->rememberToken();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}

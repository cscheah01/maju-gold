<?php

namespace App\Repositories;

use App\Models\PartnerGroupCommissionLevel;

class PartnerGroupCommissionLevelRepository extends Repository
{
    protected $_db;

    public function __construct(PartnerGroupCommissionLevel $partnerGroupCommissionLevel)
    {
        $this->_db = $partnerGroupCommissionLevel;
    }

    public function save($data)
    {
        $model = new PartnerGroupCommissionLevel;
        $model->partner_user_id = $data['partner_user_id'];
        $model->level = $data['level'];

        $model->save();
        return $model->fresh();
    }


    public function updateByPartnerUserId($data, $partnerUserId)
    {
        $model = $this->_db
            ->where('partner_user_id', '=', $partnerUserId)
            ->first();

        $model->partner_user_id = $data['partner_user_id'] ?? $model->partner_user_id;
        $model->level = $data['level'] ?? $model->level;

        $model->update();
        return $model;
    }

    public function getByPartnerUserId($partnerUserId)
    {
        $data = $this->_db->where('partner_user_id', '=', $partnerUserId)
            ->first();

        if (empty($data)) {
            return null;
        }

        return $data;
    }
}

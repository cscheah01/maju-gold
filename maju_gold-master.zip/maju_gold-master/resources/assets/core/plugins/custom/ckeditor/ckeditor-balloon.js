// CKEditor  - Rock-solid, free WYSIWYG editor with collaborative editing, 200+ features, full documentation and support: https://ckeditor.com/

// CKEditor Balloon
window.BalloonEditor = require('@ckeditor/ckeditor5-build-balloon/build/ckeditor.js');

<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Services\Admin\PackageWithdrawalRequestAdminService;

class PackageWithdrawalRequestAdminController extends Controller
{
    private $_packageWithdrawalRequestAdminService;

    public function __construct(
        PackageWithdrawalRequestAdminService $packageWithdrawalRequestAdminService
    ) {
        $this->_packageWithdrawalRequestAdminService = $packageWithdrawalRequestAdminService;
    }

    public function index()
    {
        return view('admin/package_withdrawal_request/index');
    }

    public function show($id)
    {
        $packageWithdrawalRequest = $this->_packageWithdrawalRequestAdminService->getById($id);

        if ($packageWithdrawalRequest == false) {
            abort(404);
        }

        if ($packageWithdrawalRequest == null) {
            $errorMessage = implode("<br>", $this->_packageWithdrawalRequestAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/package_withdrawal_request/show', compact('packageWithdrawalRequest'));
    }

    public function dataTable(Request $request)
    {
        $filterData = $request->only([
            'date_from',
            'date_to',
        ]);

        $data = $this->_packageWithdrawalRequestAdminService->getDataTable($filterData);

        return $data;
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'is_approved',
            'remark'
        ]);

        $result = $this->_packageWithdrawalRequestAdminService->update($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_packageWithdrawalRequestAdminService->_errorMessage);

            return back()->with('error', $errorMessage)->withInput();
        }

        return back()->with('success', "Investment withdrawal request successfully updated.");
    }
}

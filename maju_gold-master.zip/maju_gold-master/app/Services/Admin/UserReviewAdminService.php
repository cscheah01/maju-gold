<?php

namespace App\Services\Admin;

use Exception;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\UserReviewRepository;

class UserReviewAdminService extends Service
{
    protected $_userReviewRepository;

    public function __construct(
        UserReviewRepository $userReviewRepository
    ) {
        $this->_userReviewRepository = $userReviewRepository;
    }

    public function getDataTable()
    {

        $data = DB::table('user_reviews')
            ->select([
                'user_reviews.id',
                'user_reviews.name',
                'user_reviews.content',
                'user_reviews.created_at',
            ]);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $userReview = $this->_userReviewRepository->getById($id);

            if ($userReview == null) {
                return false;
            }

            return $userReview;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get user review details.");

            return null;
        }
    }

    public function createReview($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'content' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userReview = $this->_userReviewRepository->save($data);

            DB::commit();
            return $userReview;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to add user review.");

            DB::rollBack();
            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'content' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userReview = $this->_userReviewRepository->update($data, $id);

            DB::commit();
            return $userReview;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update user review details.");

            DB::rollBack();
            return null;
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $userReview = $this->_userReviewRepository->deleteById($id);

            DB::commit();
            return $userReview;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete user review.");

            DB::rollBack();
            return null;
        }
    }
}

<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use App\Services\Admin\UserWalletAdminService;

class UserWalletAdminController extends Controller
{
    private $_userWalletAdminService;

    public function __construct(UserWalletAdminService $userWalletAdminService)
    {
        $this->_userWalletAdminService = $userWalletAdminService;
    }

    public function index()
    {
        return view('admin/user_wallet/index');
    }

    public function dataTable()
    {
        $data = $this->_userWalletAdminService->getDataTable();

        return $data;
    }

    public function transactionDataTable($id){
        $data = $this->_userWalletAdminService->getTransactionDataTable($id);

        return $data;
    }

    public function show($id)
    {
        $userWallet = $this->_userWalletAdminService->getById($id);

        if ($userWallet == false) {
            abort(404);
        }

        if ($userWallet == null) {
            $errorMessage = implode("<br>", $this->_userWalletAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return view('admin/user_wallet/show', compact('userWallet'));
    }

    public function update(Request $request, $id)
    {
        $data = $request->only([
            'amount',
        ]);

        $result = $this->_userWalletAdminService->update($data, $id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userWalletAdminService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return Redirect::route('admin.user_wallet.show',  $result->id)->with('success', "User wallet successfully updated.");
    }
}

<?php

namespace App\Repositories;

use App\Models\UserWalletTransaction;

class UserWalletTransactionRepository extends Repository
{
    protected $_db;

    public function __construct(UserWalletTransaction $userWalletTransaction)
    {
        $this->_db = $userWalletTransaction;
    }

    public function save($data)
    {
        $model = new UserWalletTransaction;
        $model->user_wallet_id = $data['user_wallet_id'];
        $model->debit = $data['debit'] ?? 0;
        $model->credit = $data['credit'] ?? 0;
        $model->balance = $data['balance'];
        $model->description = $data['description'];

        $model->save();
        return $model->fresh();
    }
}

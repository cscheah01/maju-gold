<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_package_trading_records', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_package_id')->constrained();
            $table->date('date');
            $table->decimal('percent', 13, 2);
            $table->decimal('current_value', 13, 2);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_package_trading_records');
    }
};

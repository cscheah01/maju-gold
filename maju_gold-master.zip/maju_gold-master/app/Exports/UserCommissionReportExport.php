<?php

namespace App\Exports;

use App\Models\UserCommission;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\FromCollection;

class UserCommissionReportExport implements FromCollection, WithMapping, WithHeadings
{
    public function __construct($data)
    {
        $this->user_id = $data['user_id'] ?? null;
        $this->month = $data['month'] ?? null;
        $this->year = $data['year'] ?? null;
    }

    public function headings(): array
    {
        return [
            'Full Name',
            'Phone Number',
            'Amount',
            'Month & Year',
        ];
    }


    public function collection()
    {
        $userCommission = UserCommission::query();
        $userCommission = $userCommission
            ->leftjoin('users', 'user_commissions.user_id', '=', 'users.id')
            ->select(
                'user_commissions.user_id',
                'users.name as user_name',
                'users.phone_number as user_phone_number',
                DB::raw("(DATE_FORMAT(user_commissions.created_at, '%m-%Y')) as month_year"),
                DB::raw("SUM(amount) as amount"),
            );

        if ($this->user_id != null) {
            $userCommission = $userCommission->where('user_commissions.user_id', $this->user_id);
        }

        if ($this->month != null) {
            $userCommission = $userCommission->whereMonth('user_commissions.created_at', $this->month);
            $userCommission = $userCommission->whereYear('user_commissions.created_at', $this->year);
        }

        $userCommission->groupBy('user_commissions.user_id', DB::raw("DATE_FORMAT(user_commissions.created_at, '%m-%Y')"));

        $result = $userCommission->get();

        return $result;
    }


    public function map($userCommission): array
    {
        return [
            $userCommission->user_name,
            $userCommission->user_phone_number,
            $userCommission->amount,
            $userCommission->month_year,
        ];
    }
}

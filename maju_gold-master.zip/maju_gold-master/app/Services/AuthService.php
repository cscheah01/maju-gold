<?php

namespace App\Services;

use Exception;
use Carbon\Carbon;
use App\Enums\UserType;
use Illuminate\Support\Str;
use App\Enums\CountryOption;
use App\Enums\ReferralLevel;
use App\Enums\OtpRequestType;
use Illuminate\Support\Facades\DB;
use App\Repositories\UserRepository;
use Illuminate\Support\Facades\Auth;
use App\Services\LoginHistoryService;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use App\Repositories\UserWalletRepository;
use App\Repositories\VerificationCodeRepository;
use App\Repositories\PartnerGroupCommissionLevelRepository;

class AuthService extends Service
{
    protected $_loginHistoryService;
    protected $_userWalletRepository;
    protected $_userRepository;
    protected $_partnerGroupCommissionLevelRepository;
    protected $_verificationCodeRepository;

    public function __construct(
        LoginHistoryService $loginHistoryService,
        UserWalletRepository $userWalletRepository,
        UserRepository $userRepository,
        PartnerGroupCommissionLevelRepository $partnerGroupCommissionLevelRepository,
        VerificationCodeRepository $verificationCodeRepository
    ) {
        $this->_loginHistoryService = $loginHistoryService;
        $this->_userWalletRepository = $userWalletRepository;
        $this->_userRepository = $userRepository;
        $this->_partnerGroupCommissionLevelRepository = $partnerGroupCommissionLevelRepository;
        $this->_verificationCodeRepository = $verificationCodeRepository;
    }

    public function loginUser($data)
    {
        try {
            $validator = Validator::make($data, [
                'email' => 'required',
                'password' => 'required',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            if (auth()->attempt(array('email' => $data['email'], 'password' => $data['password']))) {
                $this->_loginHistoryService->createLoginHistory();

                Session::put('language', Auth::user()->language);

                return true;
            } else {
                array_push($this->_errorMessage, 'Invalid email or password.');

                return null;
            }

            throw new Exception();
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to login.");

            return null;
        }
    }

    public function logoutUser()
    {
        try {
            Auth::logout();
            Session::flush();

            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to logout.");

            return null;
        }
    }

    public function registerUser($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'ic_passport' => 'required|string|max:255',
                'password' => 'required|confirmed|min:8',
                'birthday' => 'date_format:Y-m-d|before:tommorow',
                'referral_code' => 'nullable|exists:users,code',
                'email' => 'required|string|email|max:255|unique:users,email',
                'bank_name' => 'nullable|string|max:255',
                'bank_holder_name' => 'nullable|string|max:255',
                'bank_account_number' => 'nullable|string|max:255',
                'country' => 'required|in:' . implode(",", CountryOption::getValues()),
                'phone_number' => 'required|unique:users,phone_number',
                'sms_otp' => 'required',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            //checking phone number format
            $malaysiaPhoneNumberRegex = '/^(\+?1)[0-46-9][0-9]{7,8}$/';
            $singaporePhoneNumberRegex = '/^(6|8|9)\d{7}$/';

            if (
                ($data['country'] == CountryOption::Malaysia()->value && !preg_match($malaysiaPhoneNumberRegex, $data['phone_number'])) ||
                ($data['country'] == CountryOption::Singapore()->value && !preg_match($singaporePhoneNumberRegex, $data['phone_number']))
            ) {
                array_push($this->_errorMessage, "Invalid phone number.");
                return null;
            }


            //adding phone number prefix
            if ($data['country'] == CountryOption::Malaysia()->value) {
                $data['phone_number'] = "60" . $data['phone_number'];
            } else if ($data['country'] == CountryOption::Singapore()->value) {
                $data['phone_number'] = "65" . $data['phone_number'];
            }

            //temp closed for singapore
            if ($data['country'] == CountryOption::Singapore()->value) {
                array_push($this->_errorMessage, "Whops! Something went wrong, please try again.");

                DB::rollBack();
                return null;
            }


            if (!config('app.debug')) {
                $verificationCode = $this->_verificationCodeRepository->getLastByPhoneNumber($data['phone_number']);

                if ($verificationCode == null || $data['sms_otp'] != decrypt($verificationCode->otp) || Carbon::now() > $verificationCode->expired_at) {
                    array_push($this->_errorMessage, "Your SMS OTP code is invalid or expired.");
                    throw new Exception();
                }

                $verificationCode = $this->_verificationCodeRepository->deleteById($verificationCode->id);
            }


            $user = $this->_userRepository->save($data);


            $data['wallet']['user_id'] = $user->id;
            $wallet = $this->_userWalletRepository->save($data['wallet']);

            $user->assignRole('user');



            if (!empty($data['referral_code'])) {
                $introducer = $this->_userRepository->getByCode($data['referral_code']);

                if ($introducer->hasRole(UserType::Partner()->key)) {
                    $user->assignRole(UserType::AgentOne()->key);
                } else {
                    $user->assignRole(UserType::AgentTwo()->key);
                }

                $data['partner_user_id'] = $introducer->partner_user_id;
                $data['upline_user_id'] = $introducer->id;
            } else {
                $user->assignRole(UserType::Partner()->key);
                $data['partner_user_id'] = $user->id;

                $data['partner_group_commission_level'] = [
                    'partner_user_id' => $user->id,
                    'level' => ReferralLevel::One()->key
                ];

                $partnerGroupCommissionLevel = $this->_partnerGroupCommissionLevelRepository->save($data['partner_group_commission_level']);
            }

            $data['code'] = $user->id . Str::random(10);
            $user = $this->_userRepository->update($data, $user->id);

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to register.");

            DB::rollBack();
            return null;
        }
    }


    public function sendOtp($data, $requestType)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'phone_number' => 'required|regex:/^(\+?1)[0-46-9][0-9]{7,8}$/',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                throw new Exception();
            }

            if (config('app.debug')) {
                throw new Exception();
            }

            $data['phone_number'] = "60" . $data['phone_number'];

            $user = $this->_userRepository->getByPhoneNumber($data['phone_number']);

            if ($requestType == OtpRequestType::Register()) {
                if ($user != null) {
                    DB::rollBack();

                    return [
                        'success' => false,
                        'error' => true,
                        'message' => "This phone number has been registered.",
                    ];
                }

                $verificationCode = $this->_verificationCodeRepository->getLastByPhoneNumber($data['phone_number']);

                if ($verificationCode != null && $verificationCode->expired_at > Carbon::now()) {
                    DB::rollBack();

                    return [
                        'success' => false,
                        'message' => 'Please wait awhile to resend again.',
                        'remaining_cooldown_seconds' => strtotime($verificationCode->expired_at) - strtotime(Carbon::now())
                    ];
                }
            }

            if ($requestType == OtpRequestType::ResetPassword()) {
                if ($user == null) {
                    DB::rollBack();

                    return [
                        'success' => false,
                        'error' => true,
                        'message' => "We didn't found your account with this phone number.",
                    ];
                }
            }


            $data['otp'] = rand(123456, 999999);
            $expiredMinutes = 5;
            $data['expired_at'] = Carbon::now()->addMinutes($expiredMinutes);
            $verificationCode = $this->_verificationCodeRepository->save($data);


            $ismsApiRequestResult = $this->ismsSendOTP($data['phone_number'], $data['otp'], $expiredMinutes);

            if ($ismsApiRequestResult == null || $ismsApiRequestResult != "2000 = SUCCESS") {
                throw new Exception();
            }


            DB::commit();
            return [
                'success' => true,
                'message' => 'SMS OTP successfully send, please check your phone.'
            ];
        } catch (Exception $e) {
            DB::rollBack();
            return [
                'success' => false,
                'error' => true,
                'message' => 'Oops! Something went wrong, please try again later.'
            ];
        }
    }


    public function ismsSendOTP($phoneNumber, $otp, $expiredMinutes)
    {
        try {
            $endpoint = config('services.isms.endpoint') . '/isms_send.php';
            $username = urlencode(config('services.isms.username'));
            $password = urlencode(config('services.isms.password'));

            $message = "Your OTP code is " . $otp . ". This will be expire in " . $expiredMinutes . " minutes.";
            $message = html_entity_decode($message, ENT_QUOTES, 'utf-8');
            $message = urlencode($message);

            $link = $endpoint . '?un=' . $username . '&pwd=' . $password . '&dstno=' . $phoneNumber . '&msg=' . $message . '&type=1&agreedterm=YES&sendid=63001';
            $http = curl_init($link);

            curl_setopt($http, CURLOPT_RETURNTRANSFER, TRUE);

            $result = curl_exec($http);
            curl_close($http);


            return $result;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to send request to ISMS.");

            return null;
        }
    }

    public function resetUserPassword($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'phone_number' => 'required|regex:/^(\+?1)[0-46-9][0-9]{7,8}$/',
                'sms_otp' => 'required',
                'password' => 'required|confirmed|min:8',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $data['phone_number'] = "60" . $data['phone_number'];

            $verificationCode = $this->_verificationCodeRepository->getLastByPhoneNumber($data['phone_number']);

            if ($verificationCode == null || $data['sms_otp'] != decrypt($verificationCode->otp) || Carbon::now() > $verificationCode->expired_at) {
                array_push($this->_errorMessage, "Your SMS OTP code is invalid or expired.");
                throw new Exception();
            }

            $verificationCode = $this->_verificationCodeRepository->deleteById($verificationCode->id);


            $user = $this->_userRepository->getByPhoneNumber($data['phone_number']);
            if ($user == null) {
                array_push($this->_errorMessage, "We didn't found your account with this phone number.");
                throw new Exception();
            }

            $user = $this->_userRepository->update($data, $user->id);

            DB::commit();
            return true;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to reset password.");

            DB::rollBack();
            return null;
        }
    }
}

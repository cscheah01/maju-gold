<?php

namespace App\Services\User;

use Exception;
use App\Services\Service;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use App\Repositories\UserWalletRepository;
use App\Repositories\UserWalletTransactionRepository;
use App\Repositories\WalletWithdrawalRequestRepository;

class UserWalletUserService extends Service
{
    protected $_userWalletRepository;
    protected $_userWalletTransactionRepository;
    protected $_walletWithdrawalRequestRepository;

    public function __construct(
        UserWalletRepository $userWalletRepository,
        UserWalletTransactionRepository $userWalletTransactionRepository,
        WalletWithdrawalRequestRepository $walletWithdrawalRequestRepository
    ) {
        $this->_userWalletRepository = $userWalletRepository;
        $this->_userWalletTransactionRepository = $userWalletTransactionRepository;
        $this->_walletWithdrawalRequestRepository = $walletWithdrawalRequestRepository;
    }

    public function getWalletByUserId($userId)
    {
        try {
            $data = $this->_userWalletRepository->getByUserId($userId);
            $wallet = $data->toArray();

            return $wallet;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/wallet.Fail_to_get_wallet_details'));

            return null;
        }
    }

    public function getDataTable()
    {
        $wallet = $this->_userWalletRepository->getByUserId(Auth::id());
        $walletId = $wallet->id;

        $data = DB::table('user_wallet_transactions')
            ->select([
                'user_wallet_transactions.debit',
                'user_wallet_transactions.credit',
                'user_wallet_transactions.balance',
                'user_wallet_transactions.description',
                'user_wallet_transactions.created_at',
            ])
            ->where('user_wallet_transactions.user_wallet_id', '=', $walletId);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function walletWithdrawRequest($data)
    {
        DB::beginTransaction();
        try {
            $validator = Validator::make($data, [
                'amount' => 'required|numeric|between: 0.01,99999999999.99',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userId = Auth::id();
            $wallet = $this->getWalletByUserId($userId);

            if ($data['amount'] > $wallet['balance']) {
                array_push($this->_errorMessage, __('user/wallet.Insufficient_wallet_balance'));
                throw new Exception();
            }

            $data['balance'] = $wallet['balance'] - $data['amount'];
            $wallet = $this->_userWalletRepository->updateByUserId($data, $userId);

            $data['wallet_withdrawal_request']['user_id'] = $userId;
            $data['wallet_withdrawal_request']['user_wallet_id'] = $wallet['id'];
            $data['wallet_withdrawal_request']['amount'] = $data['amount'];

            $walletWithdrawalRequest = $this->_walletWithdrawalRequestRepository->save($data['wallet_withdrawal_request']);

            $data['user_wallet_transaction']['user_wallet_id'] = $wallet['id'];
            $data['user_wallet_transaction']['balance'] = $data['balance'];
            $data['user_wallet_transaction']['debit'] = 0;
            $data['user_wallet_transaction']['credit'] = $data['amount'];
            $data['user_wallet_transaction']['description'] = 'Withdrawal request';

            $userWalletTransaction = $this->_userWalletTransactionRepository->save($data['user_wallet_transaction']);

            DB::commit();
            return $walletWithdrawalRequest;
        } catch (Exception $e) {
            array_push($this->_errorMessage, __('user/wallet.Fail_to_send_wallet_withdrawal_request'));
            DB::rollBack();
            return null;
        }
    }
}

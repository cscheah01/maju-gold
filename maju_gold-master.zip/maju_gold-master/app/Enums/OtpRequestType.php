<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

final class OtpRequestType extends Enum
{
    const Register = 0;
    const ResetPassword = 1;
}

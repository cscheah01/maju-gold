<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\SessionService;
use Illuminate\Support\Facades\Session;

class SessionController extends Controller
{
    protected $_sessionService;

    public function __construct(
        SessionService $sessionService
    ) {
        $this->_sessionService = $sessionService;
    }

    public function updateSideBarState()
    {
        if (Session::has('sidebarMinimize')) {
            Session::remove('sidebarMinimize');
        } else {
            Session::put('sidebarMinimize', true);
        }
    }

    public function updateLanguageState(Request $request)
    {
        $data = $request->only([
            'language',
        ]);

        $result = $this->_sessionService->updateUserLanguage($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_sessionService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }

        return back();
    }
}

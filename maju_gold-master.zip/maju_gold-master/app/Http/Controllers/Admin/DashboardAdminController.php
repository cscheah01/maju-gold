<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\Admin\DashboardAdminService;

class DashboardAdminController extends Controller
{
    private $_dashboardAdminService;

    public function __construct(
        DashboardAdminService $dashboardAdminService
    ) {
        $this->_dashboardAdminService = $dashboardAdminService;
    }

    public function index()
    {
        $data = $this->_dashboardAdminService->getData();

        return view('admin/dashboard/index', compact('data'));
    }
}

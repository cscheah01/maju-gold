<?php

namespace App\Services;

use App\Enums\SettingMeta;
use Exception;
use App\Repositories\SettingRepository;

class PlatformSettingService extends Service
{
    protected $_settingRepository;

    public function __construct(
        SettingRepository $settingRepository,
    ) {
        $this->_settingRepository = $settingRepository;
    }

    public function getPopUpNotice()
    {
        try {
            $platformSetting = $this->_settingRepository->getByMetaKey(SettingMeta::PopUpNotice()->key);

            return $platformSetting;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get platform pop up notice.");

            return null;
        }
    }

    public function getSliderBarNotice()
    {
        try {
            $platformSetting = $this->_settingRepository->getByMetaKey(SettingMeta::SliderBarNotice()->key);

            return $platformSetting;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get platform slider bar notice.");

            return null;
        }
    }

    public function getAllHomePageBanner()
    {
        try {
            $homePageBanners = $this->_settingRepository->getAllByMetaKey(SettingMeta::HomePageBanner()->key);

            return $homePageBanners;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get home page banner list.");

            return null;
        }
    }
}

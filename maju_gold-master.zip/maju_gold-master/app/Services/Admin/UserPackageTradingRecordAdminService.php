<?php

namespace App\Services\Admin;

use App\Repositories\UserPackageRepository;
use Exception;
use Carbon\Carbon;
use App\Services\Service;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Repositories\UserPackageTradingRecordRepository;

class UserPackageTradingRecordAdminService extends Service
{
    protected $_userPackageTradingRecordRepository;
    protected $_userPackageRepository;

    public function __construct(
        UserPackageTradingRecordRepository $userPackageTradingRecordRepository,
        UserPackageRepository $userPackageRepository
    ) {
        $this->_userPackageTradingRecordRepository = $userPackageTradingRecordRepository;
        $this->_userPackageRepository = $userPackageRepository;
    }

    public function getPackageTradingRecordByUserPackageId($userPackageId)
    {
        try {
            $packageTradingRecords = $this->_userPackageTradingRecordRepository->getAllByUserPackageId($userPackageId);

            return $packageTradingRecords;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get package trading record.");

            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'percent.*' => 'required|numeric|between: -5,5',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            $userPackage = $this->_userPackageRepository->getById($id);

            $today = Carbon::now()->format('Y-m-d');

            $todayUserPackageTradingRecord = $this->_userPackageTradingRecordRepository->getByUserPackageIdAndDate($id, $today);

            $incomingUserPackageTradingRecords = $this->_userPackageTradingRecordRepository->getIncommingRecordByUserPackageIdAndDate($id, $today);

            $newUserPackageTradingRecords = [];

            $currentValue = $todayUserPackageTradingRecord->current_value ?? $userPackage->price;

            foreach ($incomingUserPackageTradingRecords as $record) {
                $percent = $data['percent'][$record->id];
                $currentValue += $userPackage->price * ($percent / 100);

                $data['user_trading_record']['percent'] = $data['percent'][$record->id];
                $data['user_trading_record']['date'] = $record->date;
                $data['user_trading_record']['current_value'] = $currentValue;

                $newUserPackageTradingRecords[] = $data['user_trading_record'];

                if (end($incomingUserPackageTradingRecords)) {
                    $data['user_package']['return_profit_percent'] = array_sum($data['percent']);
                }
            }

            $this->_userPackageTradingRecordRepository->deleteByDateAndUserPackageId($today, $id);

            $this->_userPackageTradingRecordRepository->bulkSave($newUserPackageTradingRecords, $id);
            $data['user_package']['return_profit_date'] = $userPackage->return_profit_date;
            $userPackage = $this->_userPackageRepository->update($data['user_package'], $id);

            DB::commit();
            return $userPackage;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update user package trading record.");

            DB::rollBack();
            return null;
        }
    }
}

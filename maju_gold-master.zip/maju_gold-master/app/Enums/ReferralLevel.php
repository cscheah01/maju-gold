<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

final class ReferralLevel extends Enum
{
    const One = 0;
    const Two = 1;
    const Three = 2;
}

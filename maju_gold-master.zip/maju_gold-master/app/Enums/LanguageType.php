<?php

declare(strict_types=1);

namespace App\Enums;

use BenSampo\Enum\Enum;

final class LanguageType extends Enum
{
    const En = 0;
    const Bm = 1;
    const Ben = 2;
}

<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Services\User\DownlineUserService;

class DownlineUserController extends Controller
{
    private $_downlineUserService;

    public function __construct(
        DownlineUserService $downlineUserService
    ) {
        $this->_downlineUserService = $downlineUserService;
    }

    public function dataTable()
    {
        $data = $this->_downlineUserService->getDataTable();

        return $data;
    }
}

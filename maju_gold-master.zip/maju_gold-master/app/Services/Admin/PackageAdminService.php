<?php

namespace App\Services\Admin;

use Image;
use Exception;
use App\Services\Service;
use Illuminate\Support\Str;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Repositories\PackageRepository;
use Illuminate\Support\Facades\Validator;

class PackageAdminService extends Service
{
    protected $_packageRepository;

    public function __construct(
        PackageRepository $packageRepository
    ) {
        $this->_packageRepository = $packageRepository;
    }

    public function createPackage($data)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'image' => 'nullable|mimes:jpeg,png,jpg|max:2048',
                'price' => 'required|numeric|between: 0.00,99999999999.99',
                'gram' => 'required|numeric|between: 0.00,99999999999.99',
                'return_profit_percent' => 'required|numeric|between: 0.00,99999999999.99',
                'return_profit_days' => 'required|integer|min:0',
                'is_for_new_user' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            if (isset($data['image']) && !empty($data['image'])) {
                $image = $data['image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['image']->extension();
                $fileName = $fileName . '.' . $fileExtension;
                $destinationPath = public_path('storage/package_image');
                File::ensureDirectoryExists($destinationPath);

                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                $data['image'] = $fileName;
            } else {
                $data['image'] = null;
            }

            $package = $this->_packageRepository->save($data);

            DB::commit();
            return $package;
        } catch (Exception $e) {
            dd($e);
            array_push($this->_errorMessage, "Fail to add package.");

            DB::rollBack();
            return null;
        }
    }

    public function generateFileName()
    {
        return Str::random(5) . Str::uuid() . Str::random(5);
    }

    public function getDataTable()
    {

        $data = DB::table('packages')
            ->select([
                'packages.id',
                'packages.name',
                'packages.image',
                'packages.price',
                'packages.gram',
                'packages.return_profit_percent',
                'packages.return_profit_days',
                'packages.is_for_new_user',
                'packages.created_at',
            ])
            ->where('packages.deleted_at', '=', null);

        $result = DataTables::of($data)
            ->make();

        return $result;
    }

    public function getById($id)
    {
        try {
            $package = $this->_packageRepository->getById($id);

            if ($package == null) {
                return false;
            }

            return $package;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to get package details.");

            return null;
        }
    }

    public function deleteById($id)
    {
        DB::beginTransaction();

        try {
            $package = $this->_packageRepository->deleteById($id);

            DB::commit();
            return $package;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to delete package.");

            DB::rollBack();
            return null;
        }
    }

    public function update($data, $id)
    {
        DB::beginTransaction();

        try {
            $validator = Validator::make($data, [
                'name' => 'required|string|max:255',
                'image' => 'nullable|mimes:jpeg,png,jpg|max:2048',
                'price' => 'required|numeric|between: 0.00,99999999999.99',
                'gram' => 'required|numeric|between: 0.00,99999999999.99',
                'return_profit_percent' => 'required|numeric|between: 0.00,99999999999.99',
                'return_profit_days' => 'required|integer|min:1',
                'is_for_new_user' => 'required|boolean',
            ]);

            if ($validator->fails()) {
                foreach ($validator->errors()->all() as $error) {
                    array_push($this->_errorMessage, $error);
                }

                return null;
            }

            if (isset($data['image']) && !empty($data['image'])) {
                $image = $data['image'];
                $fileName = $this->generateFileName();
                $fileExtension = $data['image']->extension();
                $fileName = $fileName . '.' . $fileExtension;

                $destinationPath = public_path('storage/package_image');
                File::ensureDirectoryExists($destinationPath);
                $image = Image::make($image->getRealPath());
                $image->resize(600, null, function ($constraint) {
                    $constraint->aspectRatio();
                })->save($destinationPath . '/' . $fileName);

                $data['image'] = $fileName;
            } else {
                $data['image'] = null;
            }

            $package = $this->_packageRepository->update($data, $id);

            DB::commit();
            return $package;
        } catch (Exception $e) {
            array_push($this->_errorMessage, "Fail to update package details.");

            DB::rollBack();
            return null;
        }
    }
}

<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Services\User\UserPackageUserService;
use App\Services\User\PackageWithdrawalRequestUserService;
use App\Services\User\UserPackageTradingRecordUserService;

class UserPackageUserController extends Controller
{
    private $_userPackageUserService;
    private $_userPackageTradingRecordUserService;
    private $_packageWithdrawalRequestUserService;

    public function __construct(
        UserPackageUserService $userPackageUserService,
        UserPackageTradingRecordUserService $userPackageTradingRecordUserService,
        PackageWithdrawalRequestUserService $packageWithdrawalRequestUserService,
    ) {
        $this->_userPackageUserService = $userPackageUserService;
        $this->_userPackageTradingRecordUserService = $userPackageTradingRecordUserService;
        $this->_packageWithdrawalRequestUserService = $packageWithdrawalRequestUserService;
    }

    public function index()
    {
        $userId = Auth::id();
        $userPackage = $this->_userPackageUserService->getCurrentPackage($userId);

        $userPackageTradingRecords = null;
        $packageWithdrawalRequest = null;

        if ($userPackage != null) {
            $userPackageTradingRecords = $this->_userPackageTradingRecordUserService->getPackageTradingRecordByUserPackageId($userPackage['id']);
            $packageWithdrawalRequest = $this->_packageWithdrawalRequestUserService->getPackageWithdrawRequest($userPackage['id']);
        }

        $withdrawnPackage = null;
        if ($userPackage == null) {
            $withdrawnPackage = $this->_userPackageUserService->getWithdrawnPackage($userId);
        }

        if ($withdrawnPackage == true) {
            $packages = $this->_userPackageUserService->getAllPackageExcludeNewUserPackage();
        } else {
            $packages = $this->_userPackageUserService->getAllPackage();
        }

        return view('user/package/index', compact('packages', 'userPackage', 'userPackageTradingRecords', 'packageWithdrawalRequest'));
    }

    public function purchase(Request $request)
    {
        $data = $request->only([
            'package_id',
        ]);

        $result = $this->_userPackageUserService->createUserPackage($data);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userPackageUserService->_errorMessage);
            return back()->with('error', $errorMessage)->withInput();
        }
        return back()->with('success', __('user/package.Investment_plan_successfully_purchased'));
    }

    public function serve($id)
    {
        $result = $this->_userPackageUserService->serveCertificate($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userPackageUserService->_errorMessage);

            return back()->with('error', $errorMessage)->withInput();
        }
        return $result;
    }

    public function download($id)
    {
        $result = $this->_userPackageUserService->downloadCertificate($id);

        if ($result == null) {
            $errorMessage = implode("<br>", $this->_userPackageUserService->_errorMessage);

            return back()->with('error', $errorMessage)->withInput();
        }

        return $result;
    }
}
